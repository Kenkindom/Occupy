package com.example.jason.occupy;


import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by user on 2015/9/5.
 */
public class DoubleManHard extends Activity {
    int x=0;
    Double_view_hard t;  //新增TEST為Test_viewc class型態
    Double_view2_hard s;
    Double_view3_hard u;
    Button b;
    int index,index2;//left right
    int turn = 1 ,ans=1,conquer_other=0,start=0;//佔到別人的
    public String name,width;
    int test_finish=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.square3_hard);
        shape temp_shape = new shape() ;
        index = temp_shape.got_index();
        shape temp_shape2 = new shape() ;
        index2 = temp_shape2.got_index();
        t = (Double_view_hard)this.findViewById(R.id.view1_double_hard);
        s = (Double_view2_hard)this.findViewById(R.id.view2_double_hard);
        u = (Double_view3_hard)this.findViewById(R.id.view3_double_hard);

        //t.init_maps();
        Intent intent = this.getIntent();
       name = intent.getStringExtra("leve");

       //width=Integer.parseInt(wid);//寬度轉成數字
       //t.GRID_SIZE=10;可以改寬度 但是會跟前面的疊到
      if(Integer.parseInt(name)!=0) //第1關沒有黑格子 其它關要跑init_maps
       t.init_maps();
        //t.setTextView((TextView)this.findViewById(R.id.cordinate));
        b=(Button)findViewById(R.id.choose_double);

        b.setOnClickListener(new Button.OnClickListener(){

            @Override
            public void onClick(View v) {
                shape temp_shape = new shape();
                shape temp_shape2=new shape();
                t = (Double_view_hard)findViewById(R.id.view1_double_hard);
                s = (Double_view2_hard)findViewById(R.id.view2_double_hard);
                u = (Double_view3_hard)findViewById(R.id.view3_double_hard);


                if(conquer_other==1)
                {Toast toast = Toast.makeText(DoubleManHard.this, "can't conquer", Toast.LENGTH_SHORT);
                    toast.show();

                    return;
                }
                if(getstart()==0||t.blank>0)
                {	test_finish=1;
                    t.blank = 0;
                    start++;
                    Toast toast = Toast.makeText(DoubleManHard.this, "start:" + start, Toast.LENGTH_SHORT);
                    toast.show();
                    if(turn==1)//換下一個方塊
                        index = temp_shape.got_index();
                     else if(turn==2)
                        index2=temp_shape2.got_index();
                    ans=0;
                    t.change_line(t.x, t.y, t.shape, turn);
                    if(turn == 1 )
                    {
                        turn = 2 ;
                    }
                    else
                    {
                        turn = 1;
                    }
                }
              if(test_finish==1&&turn==2)//分兩個是為了要分辨要判斷誰的下一個不能下 若沒有ifelse則A方會變成判斷A方的下個方塊 但應該是要判斷B方的方塊可否下
              {
                if(t.finish(turn, index2) == 0)
                {
                    Toast toast = Toast.makeText(DoubleManHard.this, "NONO" + index, Toast.LENGTH_SHORT);
                    toast.show();
                    t.ifending=1;
                    notEnable();
                    try {
                		Thread.sleep(2000);//停1秒

                		} catch (InterruptedException e) {

                		e.printStackTrace();
                		}

                    Log.e("g over", "s");
                }
                test_finish=0;
                t.invalidate();
                s.postInvalidate();
                u.postInvalidate();
              }else if(test_finish==1&&turn==1){
           	   if(t.finish(turn, index) == 0)//設個變數代表結束
                  {
                      Toast toast = Toast.makeText(DoubleManHard.this, "NONO" + index, Toast.LENGTH_SHORT);
                      toast.show();
                      t.ifending=1;

                      notEnable();
                      try {
                  		Thread.sleep(2000);//停1秒

                  		} catch (InterruptedException e) {

                  		e.printStackTrace();
                  		}


                      Log.e("g over", "s");
                  }
                   test_finish=0;
                  t.invalidate();
                  s.postInvalidate();
                  u.postInvalidate();
              }
            }

        });

    }

    public int getImportantInt() { return index; }
    public int getImportantInt2(){return index2;}
    public int getturn(){ return turn ; }
    public int getstart(){return start;}
    public int getAnswer(){
        if(ans==0){++ans;return 0;}
        else{return 1;}
    }
    public void notEnable(){
    	 b.setEnabled(false);
    }
    public void ending(){
   	 AlertDialog.Builder ad=new AlertDialog.Builder(DoubleManHard.this);
	        ad.setTitle("score:"+t.player1Score+" vs "+t.player2Score);
	        ad.setMessage("Do you want to play again?");
	        ad.setPositiveButton("Yes", new DialogInterface.OnClickListener() {//退出按鈕
	            public void onClick(DialogInterface dialog, int i) {
	                // TODO Auto-generated method stub

	            	Intent it= new Intent();
	            	it.setClass(DoubleManHard.this,BeforeLevel.class);
	            	//it.putExtra("leve","0");
	            	//it.putExtra("widt","10");
	            	startActivity(it);
	            	DoubleManHard.this.finish();//關閉activity
	            }
	        });
	        ad.setNegativeButton("No",new DialogInterface.OnClickListener() {
	            public void onClick(DialogInterface dialog, int i) {
	            	Intent it= new Intent();
	            	it.setClass(DoubleManHard.this,Start.class);
	            	startActivity(it);
	            	DoubleManHard.this.finish();//關閉activity

	            }
	        });
	        ad.show();//示對話框
   }
}
