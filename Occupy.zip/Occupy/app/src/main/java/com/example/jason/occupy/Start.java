package com.example.jason.occupy;


import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageButton;


public class Start extends Activity {

		private Button start,setting,over;
		   ImageButton imageButton;
		protected void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);

	        setContentView(R.layout.start_main);
	        
	         start = (Button) findViewById(R.id.start_game);
			setting = (Button) findViewById(R.id.setting_game);
			over = (Button) findViewById(R.id.game_exit);
			/*imageButton=(ImageButton)findViewById(R.id.imageButtonTest);
			
			
			imageButton.setOnTouchListener(new View.OnTouchListener(){            
			    public boolean onTouch(View v, MotionEvent event) {               
		            if(event.getAction() == MotionEvent.ACTION_DOWN){       
		               //按下時的背景圖片
		               ((ImageButton)v).setImageDrawable(getResources().getDrawable(R.drawable.du07));
		              
		            }else if(event.getAction() == MotionEvent.ACTION_UP){       
		                //抬起時的正常圖片 
		                ((ImageButton)v).setImageDrawable(getResources().getDrawable(R.drawable.du06));
		                Intent it= new Intent();
						it.setClass(Start.this,MainActivity.class);
						startActivity(it);
		            }  
		            return false;       
			    }       
			});  */
		        
			/*start.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					Intent it= new Intent();
					it.setClass(Start.this,MainActivity.class);
					startActivity(it);
				}
			});*/
			start.setOnTouchListener(new OnTouchListener() {
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					if (event.getAction() == MotionEvent.ACTION_DOWN) {
						start.setBackgroundResource(R.drawable.buttonshape);
					} else if (event.getAction() == MotionEvent.ACTION_UP) {
						Intent it = new Intent();
						it.setClass(Start.this, MainActivity.class);
						startActivity(it);
						start.setBackgroundResource(R.drawable.buttonshape3);
					}
					return false;
				}

			});
			setting.setOnTouchListener(new OnTouchListener() {
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					if (event.getAction() == MotionEvent.ACTION_DOWN) {
						setting.setBackgroundResource(R.drawable.buttonshape);
					} else if (event.getAction() == MotionEvent.ACTION_UP) {
						Intent it = new Intent();
						it.setClass(Start.this, Setting.class);
						startActivity(it);
						setting.setBackgroundResource(R.drawable.buttonshape3);
					}
					return false;
				}

			});
			
			over.setOnTouchListener(new OnTouchListener() {
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					if (event.getAction() == MotionEvent.ACTION_DOWN) {
						over.setBackgroundResource(R.drawable.buttonshape);
					} else if (event.getAction() == MotionEvent.ACTION_UP) {
						ConfirmExit();
						over.setBackgroundResource(R.drawable.buttonshape3);
					}
					return false;
				}

			});
		}
		  
		  
		@Override
		public boolean onKeyDown(int keyCode, KeyEvent event) {//捕捉返回鍵
	        if ((keyCode == KeyEvent.KEYCODE_BACK)) {
	            ConfirmExit();//按返回鍵，則執行退出確認
	            return true;   
	        }   
	        return super.onKeyDown(keyCode, event);   
	    }
	    public void ConfirmExit(){//退出確認
	        AlertDialog.Builder ad=new AlertDialog.Builder(Start.this);
	        ad.setTitle("Exit");
	        ad.setMessage("Do you want to exit?");
	        ad.setPositiveButton("Yes", new DialogInterface.OnClickListener() {//退出按鈕
	            public void onClick(DialogInterface dialog, int i) {
	                // TODO Auto-generated method stub
	                Start.this.finish();//關閉activity
	                
	            }
	        });
	        ad.setNegativeButton("No",new DialogInterface.OnClickListener() {
	            public void onClick(DialogInterface dialog, int i) {
	                //不退出不用執行任何操作
	            }
	        });
	        ad.show();//示對話框
	    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        //getMenuInflater().inflate(R.menu.main, menu);
        //menu.add(1,1,1,"同機雙打");
        //menu.add(1,2,2,"連線對戰");
        //menu.add(1,3,3,"電腦對戰");
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
