package com.example.jason.occupy;




import android.app.ActionBar;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * This is the main Activity that displays the current chat session.
 */
public class BlueOnline extends Activity {
    // Debugging
    private static final String TAG = "BluetoothChat";
    private static final boolean D = true;

    // Message types sent from the BluetoothChatService Handler
    public static final int MESSAGE_STATE_CHANGE = 1;
    public static final int MESSAGE_READ = 2;
    public static final int MESSAGE_WRITE = 3;
    public static final int MESSAGE_DEVICE_NAME = 4;
    public static final int MESSAGE_TOAST = 5;

    // Key names received from the BluetoothChatService Handler
    public static final String DEVICE_NAME = "device_name";
    public static final String TOAST = "toast";

    // Intent request codes
    private static final int REQUEST_CONNECT_DEVICE_SECURE = 1;
    private static final int REQUEST_CONNECT_DEVICE_INSECURE = 2;
    private static final int REQUEST_ENABLE_BT = 3;

    // Layout Views
    private ListView mConversationView;
    private EditText mOutEditText;
    private Button mSendButton;

    // Name of the connected device
    private String mConnectedDeviceName = null;
    // Array adapter for the conversation thread
    private ArrayAdapter<String> mConversationArrayAdapter;
    // String buffer for outgoing messages
    private StringBuffer mOutStringBuffer;
    // Local Bluetooth adapter
    private BluetoothAdapter mBluetoothAdapter = null;
    // Member object for the chat services
    private BlueService mChatService = null;
    
    public int first_second=0;//接收端發送端
    int index;//什麼圖形
	int  ans=1,conquer_other=0;//佔到別人的
	public static int turn = 1;
	int first_enter=1;
	Button b,c;
	Blue_view1 tb;
	Blue_view2 sb;
	final String[] arrayGuess = new String[] { "剪刀", "石頭", "布" };
    public static int guess_finger=0;
    public static int change_who=1;
    public static int who_one;//誰是第一個
    public static int sure_who_first=0;//確定誰先
    public static int player1Score=0,player2Score=0;//算最後雙方有幾格
    public int isSecond=5,isFirst=5;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(D) Log.e(TAG, "+++ ON CREATE +++");
           
        // Set up the window layout
        setContentView(R.layout.main);
        shape temp_shape = new shape() ;
		index = temp_shape.got_index();
        tb = (Blue_view1)findViewById(R.id.bview1);
        sb = (Blue_view2)this.findViewById(R.id.bview2);
        tb.setTextView((TextView)this.findViewById(R.id.cordinate2));
        sure_who_first=0;
        change_who=1;
       // tb.convey;
        // Get local Bluetooth adapter
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        //如果mBluetoothAdapter為null 說明目前手機沒有藍芽模組
        // If the adapter is null, then Bluetooth is not supported
        if (mBluetoothAdapter == null) {
            Toast.makeText(this, "Bluetooth is not available", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        
    }

    @Override
    public void onStart() {
        super.onStart();
        if(D) Log.e(TAG, "++ ON START ++");
        
        // If BT is not on, request that it be enabled.
        // setupChat() will then be called during onActivityResult
        if (!mBluetoothAdapter.isEnabled()) {
            Intent enableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableIntent, REQUEST_ENABLE_BT);
            setupChat();
        // Otherwise, setup the chat session
        } else {
            if (mChatService == null) setupChat();
        }
    }

    @Override
    public synchronized void onResume() {
        super.onResume();
        if(D) Log.e(TAG, "+ ON RESUME +");

        // Performing this check in onResume() covers the case in which BT was
        // not enabled during onStart(), so we were paused to enable it...
        // onResume() will be called when ACTION_REQUEST_ENABLE activity returns.
        if (mChatService != null) {
            // Only if the state is STATE_NONE, do we know that we haven't started already
            if (mChatService.getState() == BlueService.STATE_NONE) {
              // Start the Bluetooth chat services
              mChatService.start();
            }
        }
    }
    
    private void setupChat() {
        Log.d(TAG, "setupChat()");

        // Initialize the array adapter for the conversation thread
        mConversationArrayAdapter = new ArrayAdapter<String>(this, R.layout.message);
        c=(Button)findViewById(R.id.choose3);
        c.setOnClickListener(new Button.OnClickListener(){//看誰先下
	         @Override
	         public void onClick(View v) {

	             who_one=(int)(Math.random()*2+1);
	             if(who_one==1){//我擲出1 所以寄給對方2
	            	 Toast toast3 = Toast.makeText(BlueOnline.this, "先發", Toast.LENGTH_SHORT);
		             toast3.show();
		             turn=1;
		             sendMessage("se");
	             }else if(who_one==2){
	            	 Toast toast4 = Toast.makeText(BlueOnline.this, "後守", Toast.LENGTH_SHORT);
		             toast4.show();
		             turn=2;
	            	 sendMessage("on");
	             }
	             sure_who_first=1;
	             b.setVisibility(View.VISIBLE);
	             c.setEnabled(false);
	             c.setVisibility(View.INVISIBLE);
	         }
        });

        b=(Button)findViewById(R.id.choose2);
        b.setOnClickListener(new Button.OnClickListener(){
	         @Override
	         public void onClick(View v) {
	        	 shape temp_shape = new shape() ;
		     	 index = temp_shape.got_index();//改變圖形
		     	tb=(Blue_view1)findViewById(R.id.bview1);
		     	sb = (Blue_view2)findViewById(R.id.bview2);
		     	//first_enter++;
		     	if(conquer_other==1)
	    		{Toast toast = Toast.makeText(BlueOnline.this, "can't conquer", Toast.LENGTH_SHORT);
	             toast.show();
                 
	    			return;
	    		}
		     	ans=0;
        	    tb.change_line(tb.x, tb.y, tb.shape, turn);
        	    
        	   /* if(tb.finish(turn, index) == 0)//index應該要是對方的 但這裡是我方下一個   無法確定對方還能不能下
	    		{
	    			Toast toast = Toast.makeText(BlueOnline.this, "NONO", Toast.LENGTH_SHORT);
		             toast.show();
	    			tb.setEnabled(false);
	    		}*/
        	    
		    	tb.postInvalidate();	
		    	
        	// test++;
        	//Toast.makeText(BlueOnline.this, "g"+test, Toast.LENGTH_SHORT).show();
        	//sendMessage(test);
	    		if(change_who==1)
	    			change_who=2;
	    		else
	    			change_who=1;
		     	sb.postInvalidate();
		     	Toast toast2 = Toast.makeText(BlueOnline.this, "" + first_second + "s" + tb.convey, Toast.LENGTH_SHORT);
	             toast2.show();
		     	
	             //tb.mGridArray[0][0]=1;
	             //int[][] bb=tb.mGridArray;
	             
			   String message = tb.convey;
	           sendMessage(message);
	         }
        });
        // Initialize the BluetoothChatService to perform bluetooth connections
        mChatService = new BlueService(this, mHandler);

        // Initialize the buffer for outgoing messages
        mOutStringBuffer = new StringBuffer("");
    }

    @Override
    public synchronized void onPause() {
        super.onPause();
        if(D) Log.e(TAG, "- ON PAUSE -");
    }

    @Override
    public void onStop() {
        super.onStop();
        if(D) Log.e(TAG, "-- ON STOP --");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        // Stop the Bluetooth chat services
        if (mChatService != null) mChatService.stop();
        if(D) Log.e(TAG, "--- ON DESTROY ---");
        
    }
   
    //設定可被發現狀態  300秒之內使其它藍芽裝置可發現目前手機
    private void ensureDiscoverable() {
        if(D) Log.d(TAG, "ensure discoverable");
        if (mBluetoothAdapter.getScanMode() !=
            BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE) {
            Intent discoverableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
            discoverableIntent.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300);
            startActivity(discoverableIntent);
        }
    }

    /**
     * Sends a message.
     * @param message  A string of text to send.
     */
    //當點擊主介面的"發送"按鈕 會將文字方塊中輸入的資訊發送給另一端的藍芽裝置
    private void sendMessage(String message) {
        // Check that we're actually connected before trying anything
        //在發送訊息之前核對藍芽裝置是否成功連接
    	if (mChatService.getState() != BlueService.STATE_CONNECTED) {
            Toast.makeText(this, R.string.not_connected, Toast.LENGTH_SHORT).show();
            return;
        }

        // Check that there's actually something to send
    	//檢查文字輸入框是否有文字
        if (message.length() > 0) {
            // Get the message bytes and tell the BluetoothChatService to write
            //獲得發送訊息的位元組型式的資料
        	byte[] send = message.getBytes();
            mChatService.write(send);

            // Reset out string buffer to zero and clear the edit text field
           // mOutStringBuffer.setLength(0);
           // mOutEditText.setText(mOutStringBuffer);
        }
    }

    // The action listener for the EditText widget, to listen for the return key
    private TextView.OnEditorActionListener mWriteListener =
        new TextView.OnEditorActionListener() {
        public boolean onEditorAction(TextView view, int actionId, KeyEvent event) {
            // If the action is a key-up event on the return key, send the message
            if (actionId == EditorInfo.IME_NULL && event.getAction() == KeyEvent.ACTION_UP) {
                String message = view.getText().toString();
                sendMessage(message);
            }
            if(D) Log.i(TAG, "END onEditorAction");
            return true;
        }
    };

    private final void setStatus(int resId) {
        final ActionBar actionBar = getActionBar();
        actionBar.setSubtitle(resId);
    }

    private final void setStatus(CharSequence subTitle) {
        final ActionBar actionBar = getActionBar();
        actionBar.setSubtitle(subTitle);
    }

    // The Handler that gets information back from the BluetoothChatService
    private final Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
            case MESSAGE_STATE_CHANGE:
                if(D) Log.i(TAG, "MESSAGE_STATE_CHANGE: " + msg.arg1);
                switch (msg.arg1) {
                case BlueService.STATE_CONNECTED:
                    setStatus(getString(R.string.title_connected_to, mConnectedDeviceName));
                    mConversationArrayAdapter.clear();
                    //guess_first_or_second();//連到後決定順序
                    //sendMessage(""+guess_finger);
                    break;
                case BlueService.STATE_CONNECTING:
                    setStatus(R.string.title_connecting);
                    break;
                case BlueService.STATE_LISTEN:
                	
                case BlueService.STATE_NONE:
                    setStatus(R.string.title_not_connected);
                    break;
                }
                break;
            case MESSAGE_WRITE:
                byte[] writeBuf = (byte[]) msg.obj;
                // construct a string from the buffer
                String writeMessage = new String(writeBuf);
                mConversationArrayAdapter.add("Me:  " + writeMessage);
                break;
            case MESSAGE_READ:
                byte[] readBuf = (byte[]) msg.obj;
                // construct a string from the valid bytes in the buffer
                String readMessage = new String(readBuf, 0, msg.arg1);
                mConversationArrayAdapter.add(mConnectedDeviceName+":  " + readMessage);
                Toast.makeText(BlueOnline.this, "lin" + readMessage, Toast.LENGTH_SHORT).show();
                	//readMessage:從對方接收到的字串
                
                if(sure_who_first==1&& Integer.valueOf(readMessage.substring(0, 1))==9)
                {//接收方  對方不能在下了 所以寄9過來
                	Toast toast = Toast.makeText(BlueOnline.this, "End-" + index, Toast.LENGTH_SHORT);
 		             toast.show();
 	    			tb.setEnabled(false);
 	    			b.setEnabled(false);
 	    			b.setVisibility(View.INVISIBLE);
 	    			finish_score();
                }
                if(sure_who_first==1&& Integer.valueOf(readMessage.substring(0, 1))!=9)
                {  int sum=1;

                  for(int i=0;i<9;i++)//存入thirdArray
                  {
                  	for(int j=0;j<9;j++)
                  	{
                  		tb.thirdArray[i][j]= Integer.valueOf(readMessage.substring(sum, sum + 1));
                  		sum++;
                  	}
                  }
                 
                 // sum=1;
                  Log.i(TAG, "bu" + turn);
                  if(turn==1)
                    tb.change_line2(2);//檢查邊界一行或一列換色
                  else
                    tb.change_line2(1);
                  
                 /* if(turn==1)
                    tb.change_line(tb.x, tb.y, tb.shape, 2);
                  else if(turn==2)
                    tb.change_line(tb.x, tb.y, tb.shape, 1);*/
                  
                  for(int i=0;i<9;i++)//全放到mGridArray
                  {
                  	for(int j=0;j<9;j++)
                  	{
                  		tb.mGridArray[i][j]=tb.thirdArray[i][j];
                  		//sum++;
                  	}
                  }
                  if(tb.finish(turn, index) == 0)//index應該要是對方的 但這裡是我方下一個   無法確定對方還能不能下
  	    		  {
  	    			Toast toast = Toast.makeText(BlueOnline.this, "NONO" + index, Toast.LENGTH_SHORT);
  		             toast.show();
  	    			tb.setEnabled(false);
  	    			b.setEnabled(false);
  	    			b.setVisibility(View.INVISIBLE);
  	    			ending();
  	    		  }
                  tb.postInvalidate();
                 /* if(Integer.valueOf(readMessage.substring(0,1))==1)
                      turn=2;
                     else
                      turn=1;*/
                  if(Integer.valueOf(readMessage.substring(0, 1))==1)
                	  change_who=2;
                  else
                      change_who=1;
                }//sure_who_first==1
                
             if(sure_who_first==0)
             { 
                isSecond=readMessage.compareTo("se");
                 isFirst=readMessage.compareTo("on");
                if(isSecond==0)//readMessage和se相同
                {
                	 Toast.makeText(BlueOnline.this, "後守", Toast.LENGTH_SHORT).show();//後下
                     turn=2;
                }
                if(isFirst==0)//readMessage和se相同
                {
                	 Toast.makeText(BlueOnline.this, "先攻", Toast.LENGTH_SHORT).show();//後下
                	 turn=1;
                }
                //Toast.makeText(BlueOnline.this,"A"+ readMessage+"B"+guess_finger, Toast.LENGTH_SHORT).show();
                sure_who_first=1;
                b.setVisibility(View.VISIBLE);
                c.setEnabled(false);
                c.setVisibility(View.INVISIBLE);
             }
              
                break;
            case MESSAGE_DEVICE_NAME:
                // save the connected device's name
                mConnectedDeviceName = msg.getData().getString(DEVICE_NAME);
                Toast.makeText(getApplicationContext(), "Connected to "
                        + mConnectedDeviceName, Toast.LENGTH_SHORT).show();
                break;
            case MESSAGE_TOAST:
                Toast.makeText(getApplicationContext(), msg.getData().getString(TOAST),
                        Toast.LENGTH_SHORT).show();
                exitTheDoor();
                break;
            }
        }
    };

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(D) Log.d(TAG, "onActivityResult " + resultCode);
        switch (requestCode) {
        case REQUEST_CONNECT_DEVICE_SECURE:
            // When DeviceListActivity returns with a device to connect
            if (resultCode == Activity.RESULT_OK) {
                connectDevice(data, true);
            }
            break;
        case REQUEST_CONNECT_DEVICE_INSECURE:
            // When DeviceListActivity returns with a device to connect
            if (resultCode == Activity.RESULT_OK) {
                connectDevice(data, false);
            }
            break;
        case REQUEST_ENABLE_BT:
            // When the request to enable Bluetooth returns
            if (resultCode == Activity.RESULT_OK) {
                // Bluetooth is now enabled, so set up a chat session
                setupChat();
            } else {
                // User did not enable Bluetooth or an error occurred
                Log.d(TAG, "BT not enabled");
                Toast.makeText(this, R.string.bt_not_enabled_leaving, Toast.LENGTH_SHORT).show();
                //finish();
            }
        }
    }

    private void connectDevice(Intent data, boolean secure) {
        // Get the device MAC address
        String address = data.getExtras()
            .getString(DeviceList.EXTRA_DEVICE_ADDRESS);
        // Get the BluetoothDevice object
        BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(address);
        // Attempt to connect to the device
        mChatService.connect(device, secure);
        Toast toast = Toast.makeText(BlueOnline.this, "qq" + address, Toast.LENGTH_SHORT);
        toast.show();
        first_second++;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.option_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent serverIntent = null;
        switch (item.getItemId()) {
        case R.id.secure_connect_scan:
            // Launch the DeviceListActivity to see devices and do scan
            serverIntent = new Intent(this, DeviceList.class);
            startActivityForResult(serverIntent, REQUEST_CONNECT_DEVICE_SECURE);
            return true;
       /* case R.id.insecure_connect_scan:
            //menu->option_menu
            // Launch the DeviceListActivity to see devices and do scan
            serverIntent = new Intent(this, DeviceList.class);
            startActivityForResult(serverIntent, REQUEST_CONNECT_DEVICE_INSECURE);
            return true;*/
        case R.id.discoverable:
            // Ensure this device is discoverable by others
            ensureDiscoverable();
            return true;
        }
        return false;
    }
    @Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {//捕捉返回鍵
        if ((keyCode == KeyEvent.KEYCODE_BACK)) {
        	 if (mChatService != null) mChatService.stop();
 		    
        	Intent it= new Intent();
			it.setClass(this,MainActivity.class);
			startActivity(it);
			 BlueOnline.this.finish();
            return true;   
        }   
        return super.onKeyDown(keyCode, event);   
    }
    public int getImportantInt() { return index; }
	public int getturn(){ return turn ; }
	public int getChange(){return change_who;}
	public int getAnswer(){
		if(ans==0){++ans;return 0;}
		else{return 1;}
	}
	public int getFirstEnter(){
		return first_enter;
	}
	public void exitTheDoor(){
		 //Toast.makeText(BlueOnline.this,"GGGGGG", Toast.LENGTH_SHORT).show();
		 if (mChatService != null) mChatService.stop();
		 
		 BlueOnline.this.finish();
         
	}
	public void ending(){
		sendMessage("9");//結束了
		finish_score();
	}
	public void finish_score(){
   	 
    	for( int i = 0 ; i < 9 ; i++ )
        {
            for( int j = 0 ; j < 9 ; j++ )
            {
               if(tb.mGridArray[i][j]==1)
            	   player1Score++;
               else if(tb.mGridArray[i][j]==2)
            	   player2Score++;
            }
        }
    	Toast.makeText(this, "End:" + player1Score + " to " + player2Score, Toast.LENGTH_LONG).show();
    	String whoFirst="";
    	if(turn==1&&player1Score>player2Score)
    		whoFirst="You Win";
    	else if(turn==2&&player1Score>player2Score)
    		whoFirst="You Lose";
    	else if(turn==1&&player1Score<player2Score)
    		whoFirst="You Lose";
    	else if(turn==2&&player1Score<player2Score)
    		whoFirst="You Win";
    	else if(player1Score==player2Score)
    		whoFirst="Tie";
    	try {
    		Thread.sleep(1500);//停2秒
    		
    		} catch (InterruptedException e) {
    			
    		e.printStackTrace();
    		}
    	 AlertDialog.Builder ad=new AlertDialog.Builder(BlueOnline.this);
	        ad.setTitle("score:"+player1Score+" to "+player2Score);
	        ad.setMessage(""+whoFirst);
	        ad.setPositiveButton("確定", new DialogInterface.OnClickListener() {//退出按鈕
	            public void onClick(DialogInterface dialog, int i) {
	                // TODO Auto-generated method stub
	            	
	            	player1Score=0;player2Score=0;
	            	BlueOnline.this.finish();//關閉activity
	            }
	        });
	        ad.show();//示對話框
    }
    public void guess_first_or_second(){
    	Dialog alertDialog = new AlertDialog.Builder(this).
                setTitle("猜拳決定先後並從右上角連線").  
                  
                setItems(arrayGuess, new DialogInterface.OnClickListener() {
   
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //Toast.makeText(Dialog_AlertDialogDemoActivity.this, arrayFruit[which], Toast.LENGTH_SHORT).show();  
                    	if(which==0)
                    	{
                    		guess_finger=1;//剪刀
                    	}
                    	else if(which==1)
                    	{
                    		guess_finger=2;//石頭
                    	}else if(which==2)
                    	{
                    		guess_finger=3;//步
                    	}
                    	sendMessage(""+guess_finger);
                    }  
                }).  
                /*setNegativeButton("取消", new DialogInterface.OnClickListener() {  
  
                    @Override  
                    public void onClick(DialogInterface dialog, int which) {  
                    	dialog.dismiss();
                    }  
                }). */ 
                create();
    	alertDialog.show();
    	
    }
    
}
