package com.example.jason.occupy;

public class shape {
	
	 protected int shape_id[][] = 
	 {
	    {-10,-5,0,5,10},		//����  0
	   	{-2,-1,0,1,2},			//���
	    {-5,-1,0,1,5},			//�Q�r
	    {-6,-1,4,5,6},			//L 1
	   	{-6,-5,-4,-1,4},		//L 2 �k��90��
	   	{-6,-5,-4,1,6},			//L 3 �k��180��
	  	{-4,1,4,5,6},			//L 4 �k��270��
	   	{-6,-4,-1,0,1},			//U 1
		{-6,-5,-1,4,5},			//U 2 �k��90��
	    {-6,-5,-4,-1,1},		//U 3 �k��180��
	   	{-5,-4,1,5,6},			//U 4 �k��270��
	   	{-6,-5,-4,0,5},			//T 1
	    {-4,-1,0,1,6},			//T 2 �k��90��
	   	{-5,0,4,5,6},			//T 3 �k��180��
	   	{-6,-1,0,1,4}			//T 4 �k��270��
	};
	 int shape_i =(int)(Math.random()*15);
	 public int got_index()
	{
			return shape_i ;
	}
	 
	 public void getShape_id(int i , int[] temp )
	 {
		 for( int j = 0 ; j < 5 ; j++ )
		 {
			 temp[j] = shape_id[i][j] ;
		 }
	 }
	 
	 public void adjust(int i ,int[] temp)
	 {
		 getShape_id(i,temp) ;
		 temp[0] = temp[0] + 12 ;
		 temp[1] = temp[1] + 12 ;
		 temp[2] = temp[2] + 12 ;
		 temp[3] = temp[3] + 12 ;
		 temp[4] = temp[4] + 12 ;
	 }
	 
	 public void getShape_XY(int i , int[][] temp)//5x2
	 {
		 int ad_temp[]=new int[5] ;
		 int add_temp[] = new int [2] ;
		 adjust(i,ad_temp) ;
		 int x ;
		 for( x = 0 ; x < 5 ; x++ )
		 {
			temp[x][0] = ad_temp[x] % 5 ;//x�y��
			temp[x][1] = ad_temp[x] / 5 ;//y�y��
		 }
		 add_temp[0] = temp[2][0] ;
		 add_temp[1] = temp[2][1] ;
		 
		 for( x= 0 ; x < 5 ; x++ )
		 {
			 temp[x][0] = temp[x][0] - add_temp[0] ;
			 temp[x][1] = temp[x][1] - add_temp[1] ;
		 }
	 }
}