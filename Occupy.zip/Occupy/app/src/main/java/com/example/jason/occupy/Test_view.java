package com.example.jason.occupy;


import java.util.Random;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class Test_view extends View {
	protected static int GRID_SIZE = 10;
    protected int GRID_WIDTH =70;
    protected static int CHESS_DIAMETER = 30; // 棋的直径
    protected static int mStartX;// 棋盘定位的左上角X
    protected static int mStartY;// 棋盘定位的左上角Y

    private Bitmap[] mChessBW; // 黑棋和白棋
    private static int[][] mGridArray; // 网格
    private static int[][] staticArray;
    private static int[][] thirdArray;
    private static int[][] rowAndCol;


    boolean key = false;

    Test_view2 s;

    int shape[][] = new int[5][2];//目前圖形
    int turn = 0 ;
    int wbflag = 1; //该下白棋了=2，该下黑棋了=1. 这里先下黑棋（黑棋以后设置为机器自动下的棋子）
    int mWinFlag = 0;
    int makeup=1;//按的次數
    int now_up=makeup;
    int x;
    int y;
    int if_conquer=0,if_release=0;
    public static int blank=0;//玩家是否有下
    private final int BLACK=1;
    private final int WHITE=2;

    int mGameState = GAMESTATE_RUN; //游戏阶段：0=尚未游戏，1=正在进行游戏，2=游戏结束
    static final int GAMESTATE_PRE = 0;
    static final int GAMESTATE_RUN = 1;
    static final int GAMESTATE_PAUSE = 2;
    static final int GAMESTATE_END = 3;


    public TextView mStatusTextView; //  根据游戏状态设置显示的文字
    public int ai_level=0;
    public Bitmap bitmap,bitmap2,bitmaptest,bitmaptest2;
    public int ifending=0;
    public int playerScore=0,aiScore=0;//最後的分數
    private Bitmap btm1;
    private final Paint mPaint = new Paint();
    private final Paint mPaint2=new Paint();
    private final Paint mPainttest1=new Paint();
    private final Paint mPainttest2=new Paint();
    CharSequence mText;
    CharSequence STRING_WIN = "White win! /n Press Fire Key to start new game.";
    CharSequence STRING_LOSE = "Black win! /n Press Fire Key to start new game.";
    CharSequence STRING_EQUAL = "Cool! You are equal! /n Press Fire Key to start new Game.";

    public Test_view(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
      }

    public Test_view(Context context, AttributeSet attrs) { //好像调用的是这个构造函数，为什么不是前面的呢
        super(context, attrs);
        this.setFocusable(true);  //20090530
        this.setFocusableInTouchMode(true);

        init();
    }



    public void init() {
        mGameState = 1; //設置遊戲為開始狀態
        wbflag = BLACK; //初始为先下黑棋
        mWinFlag = 0; //清空输赢标志。
        mGridArray = new int[GRID_SIZE-1][GRID_SIZE-1];
        staticArray = new int[GRID_SIZE-1][GRID_SIZE-1];
        thirdArray=new int[GRID_SIZE-1][GRID_SIZE-1];
		rowAndCol = new int [2][GRID_SIZE-1];

        turn = 1 ;


        for(int i=0;i<GRID_SIZE-1;i++)
        {
        	for(int j=0;j<GRID_SIZE-1;j++)
        	{
        		staticArray[i][j]=0;
        		thirdArray[i][j]=0;
        	}
        }


        mChessBW = new Bitmap[4];
        s = (Test_view2)this.findViewById(R.id.view2);//不確定要不要
  }


    public void setTextView(TextView tv){
        mStatusTextView =tv;
        mStatusTextView.setVisibility(View.INVISIBLE);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        mStartX = w/GRID_SIZE;
        mStartY =  h/GRID_SIZE;
    	GRID_WIDTH=w/(GRID_SIZE+1);//11
    	CHESS_DIAMETER=w/(GRID_SIZE+1);
        super.onSizeChanged(w, h, oldw, oldh);
    }

    public void check_bound(int temp[][],int x,int y)
    {
    	int up=0,down=0,left=0,right=0,just_x=0,just_y=0;

    	for(int i = 0 ; i < 5 ; i++ )
    	{
    		if(x+temp[i][0] < 0)
    		{
    			up = 1 ;
    			just_x = 1 ;
    			break ;
    		}
    		else if(x+temp[i][0] >= GRID_SIZE-1)
    		{
    			down = 1 ;
    			just_x = -1 ;
    			break ;
    		}
    		else if(y+temp[i][1] < 0)
    		{
    			left = 1 ;
    			just_y = 1 ;
    			break ;
    		}
    		else if(y+temp[i][1] >= GRID_SIZE-1)
    		{
    			right = 1 ;
    			just_y = -1 ;
    			break ;
    		}
    	}

    	if( up==1 || down==1 || left==1 || right==1 )
    	{
    		for(int i = 0;i < 5;i++)
    		{
    			temp[i][0] += just_x ;
    			temp[i][1] += just_y ;
    		}
    		check_bound(temp,x,y) ;
    	}
    	else
    	{
    		return ;
    	}
    }


    int test;
     @Override
    public boolean onTouchEvent(MotionEvent event){
        switch (mGameState) {
        case GAMESTATE_PRE:
            break;
        case GAMESTATE_RUN: {

                float x1=event.getX();
                float y1=event.getY();
                float x0 = GRID_WIDTH - (event.getX() - mStartX) % GRID_WIDTH;
                float y0 = GRID_WIDTH - (event.getY() - mStartY) % GRID_WIDTH;
                x = (int) ((event.getX() - mStartX) / GRID_WIDTH) ;//點的X位子
                y = (int) ((event.getY() - mStartY) / GRID_WIDTH) ;


                shape temp_shape = new shape() ;
                linear parent = (linear)getContext(); // I meant this line
                int index = parent.getImportantInt();
                test = index;


            wbflag = parent.getturn();

                switch(event.getAction())
                {
                case MotionEvent.ACTION_DOWN:
                	if(ifending==1){//結束時
                		finish_score();
                        
                        ifending=0;
                        playerScore=0;aiScore=0;
                	}
                	now_up=makeup;
        			temp_shape.getShape_XY(index, shape);
        			check_bound(shape,x,y);
                	for(int i = 0 ; i < GRID_SIZE-1 ; i++ )//GRID_SIZE=10
                	{
                		for(int j = 0 ; j < GRID_SIZE-1 ; j++ )
                		{
                			staticArray[i][j] = mGridArray[i][j];//存進去
                		}
                	}
                	if ((x >= 0 && x < GRID_SIZE - 1) && (y >= 0 && y < GRID_SIZE - 1))
                    {
                		if (mGridArray[x][y] == 0||mGridArray[x][y] == 1||mGridArray[x][y] == 2)
                        {
                            if (wbflag == BLACK)
                            {
                               for( int i = 0 ; i < 5 ; i++)
                                {
                                	putChess2(x+shape[i][0], y+shape[i][1], BLACK);
                                }
                            }
                            else if (wbflag == WHITE)
                            {
                                for( int i = 0 ; i < 5 ; i++)
                                {
                                	putChess2(x+shape[i][0], y+shape[i][1], WHITE);
                                }
                            }

                        }
                    }
                	break;
                case MotionEvent.ACTION_UP:
                	makeup++;

                	for(int i = 0 ; i < GRID_SIZE-1 ; i++ )
                	{
                		for(int j = 0 ; j < GRID_SIZE-1 ; j++ )
                		{
                			thirdArray[i][j]=mGridArray[i][j];
                			if(thirdArray[i][j]!=3)//寫在這會是在按確定後下個才回出現 所以不能寫這
                			{

                				if_conquer=0;
                				blank++;//確認有下棋
                			}
                		}
                	}
                	check_bound(shape,x,y);
                	if ((x >= 0 && x < GRID_SIZE - 1) && (y >= 0 && y < GRID_SIZE - 1))
                    {
                        if (mGridArray[x][y] == 0 ||mGridArray[x][y] == 1||mGridArray[x][y] == 2)
                        {
                            if (wbflag == BLACK)
                            {
                               for( int i = 0 ; i < 5 ; i++)
                                {
                                	putChess3(x+shape[i][0], y+shape[i][1], BLACK);//上面的格子
                                }

                                turn = 2 ;
                                wbflag = WHITE;
                            }
                            else if (wbflag == WHITE)
                            {
                            	for( int i = 0 ; i < 5 ; i++)
                                {
                                	putChess3(x+shape[i][0], y+shape[i][1], WHITE);
                                }
                                turn = 1 ;
                                wbflag = BLACK;
                            }
                        }
                    }
                	break;
                case MotionEvent.ACTION_MOVE:
                	now_up=makeup;
                	for(int i = 0 ; i < GRID_SIZE-1 ; i++ )
                	{
                		for(int j = 0 ; j < GRID_SIZE-1 ; j++ )
                		{
                			staticArray[i][j] = mGridArray[i][j]  ;
                		}
                	}
                	check_bound(shape,x,y);
                	if ((x >= 0 && x < GRID_SIZE - 1) && (y >= 0 && y < GRID_SIZE - 1))
                    {
                		if (mGridArray[x][y] == 0||mGridArray[x][y] == 1||mGridArray[x][y] == 2)
                        {
                            if (wbflag == BLACK)
                            {
                               for( int i = 0 ; i < 5 ; i++)
                                {
                                	putChess2(x+shape[i][0], y+shape[i][1], BLACK);
                                }
                            }
                            else if (wbflag == WHITE)
                            {
                                for( int i = 0 ; i < 5 ; i++)
                                {
                                	putChess2(x+shape[i][0], y+shape[i][1], WHITE);
                                }
                            }
                        }
                    }
                	break;
                	default:
                		break;
                }


            }

            break;
        case GAMESTATE_PAUSE:
            break;
        case GAMESTATE_END:
            break;
        }

        this.invalidate();
        return true;

    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent msg) {
        //Log.e("KeyEvent.KEYCODE_DPAD_CENTER", " " + keyCode);

        if(keyCode == KeyEvent.KEYCODE_DPAD_CENTER){
            switch(mGameState){
            case GAMESTATE_PRE:
                break;
            case GAMESTATE_RUN:
                break;
            case GAMESTATE_PAUSE:
                break;
            case GAMESTATE_END:
            {

                Log.e("Fire Key Pressed:::", "FIRE");
                mGameState = GAMESTATE_RUN;
                this.setVisibility(View.VISIBLE);
                this.mStatusTextView.setVisibility(View.INVISIBLE);
                this.init();
                this.invalidate();


            }
                break;
            }
        }

        return super.onKeyDown(keyCode, msg);
    }

    @Override
    public void onDraw(Canvas canvas) {

        //canvas.drawColor(Color.BLUE);
    	canvas.drawColor(getResources().getColor(R.color.red_player_light3));
        bitmap = Bitmap.createBitmap(CHESS_DIAMETER, CHESS_DIAMETER, Bitmap.Config.ARGB_8888);
        Canvas canvas2 = new Canvas(bitmap);
        bitmap2 = Bitmap.createBitmap(CHESS_DIAMETER, CHESS_DIAMETER, Bitmap.Config.ARGB_8888);
        Canvas canvas22 = new Canvas(bitmap2);
        bitmaptest = Bitmap.createBitmap(CHESS_DIAMETER, CHESS_DIAMETER, Bitmap.Config.ARGB_8888);
        Canvas canvastest = new Canvas(bitmaptest);
        bitmaptest2 = Bitmap.createBitmap(CHESS_DIAMETER, CHESS_DIAMETER, Bitmap.Config.ARGB_8888);
        Canvas canvastest2 = new Canvas(bitmaptest2);
        Resources r = this.getContext().getResources();

        Drawable tile = r.getDrawable(R.drawable.pink);
        tile.setBounds(0, 0, CHESS_DIAMETER, CHESS_DIAMETER);//26X26
        tile.draw(canvas2);
        mChessBW[0] = bitmap;

        Drawable tile2 = r.getDrawable(R.drawable.green);
        tile2.setBounds(0, 0, CHESS_DIAMETER, CHESS_DIAMETER);
        tile2.draw(canvas22);
        mChessBW[1] = bitmap2;
        Drawable tiletest = r.getDrawable(R.drawable.playerjustput);
        tiletest.setBounds(0, 0, CHESS_DIAMETER, CHESS_DIAMETER);
        tiletest.draw(canvastest);
        mChessBW[2] = bitmaptest;

        Drawable tiletest2 = r.getDrawable(R.drawable.computerjustput);
        tiletest2.setBounds(0, 0, CHESS_DIAMETER, CHESS_DIAMETER);
        tiletest2.draw(canvastest2);
        mChessBW[3] = bitmaptest2;
        //----------------------------------------------------------修改顏色------------------------------------------------------------------------
        // 画棋盘

            Paint paintRect = new Paint();
            paintRect.setColor(Color.RED);
            paintRect.setStrokeWidth(2);
            paintRect.setStyle(Style.STROKE);

            for (int i = 0; i < GRID_SIZE-1; i++) {
                for (int j = 0; j < GRID_SIZE-1; j++) {
                    int mLeft = i * GRID_WIDTH + mStartX;
                    int mTop = j * GRID_WIDTH + mStartY;
                    int mRright = mLeft + GRID_WIDTH;
                    int mBottom = mTop + GRID_WIDTH;
                    canvas.drawRect(mLeft, mTop, mRright, mBottom, paintRect);
                }
            }

            //画棋盘的外边框
            paintRect.setStrokeWidth(10);
            canvas.drawRect(mStartX, mStartY, mStartX + GRID_WIDTH*(GRID_SIZE-1), mStartY + ( GRID_WIDTH*(GRID_SIZE-1)), paintRect);

            linear parent = (linear)getContext();//取的parent的請求
            int answer=parent.getAnswer();
            //mGridArray[5][5]=7;
        if(answer==0)//按下確定才會=0 所以才會把它匯入mGridArray
        {

        	for(int i = 0 ; i < GRID_SIZE-1 ; i++ )
        	{
        		for(int j = 0 ; j < GRID_SIZE-1 ; j++ )
        		{
                    if(thirdArray[i][j]==-1){thirdArray[i][j]=1;}
                    else if (thirdArray[i][j]==-2){thirdArray[i][j]=2;}
        			 mGridArray[i][j]=thirdArray[i][j];
        		}
        	}
            for(int i = 0 ; i < GRID_SIZE-1 ; i++ )
            {
                for(int j = 0 ; j < GRID_SIZE-1 ; j++ )
                {

                    thirdArray[i][j]=mGridArray[i][j];
                }
            }
           
            computerAIDifficult();

            for(int i = 0 ; i < GRID_SIZE-1 ; i++ )
            {
                for(int j = 0 ; j < GRID_SIZE-1 ; j++ )
                {

                    mGridArray[i][j]=thirdArray[i][j];
                }
            }

            if(checkEnd(2, mGridArray)){
                Toast toast3 = Toast.makeText(linearfunc, "player have no Position!!!!!!", Toast.LENGTH_SHORT);
                toast3.show();
                ifending=1;
            }

        }
        //画棋子
            paintRect.setStrokeWidth(2);
        for (int i = 0; i <GRID_SIZE-1; i++) {
            for (int j = 0; j <GRID_SIZE-1; j++) {
            	 Paint paintCircle = new Paint();
            	 paintCircle.setStrokeWidth(2);
               if(mGridArray[i][j]== BLACK)//非0就畫
               {
            	   canvas.drawBitmap(mChessBW[0], mStartX + (i) * GRID_WIDTH  , mStartY + (j)* GRID_WIDTH  , mPaint);


               }
               else if(mGridArray[i][j] == WHITE)
               {
            	   canvas.drawBitmap(mChessBW[1], mStartX + (i) * GRID_WIDTH, mStartY + (j) * GRID_WIDTH, mPaint2);

               }
               else if(mGridArray[i][j] == -1)
               {
                   canvas.drawBitmap(mChessBW[2], mStartX + (i) * GRID_WIDTH, mStartY + (j) * GRID_WIDTH, mPainttest1);

               }
               else if(mGridArray[i][j] == -2)
               {
                   canvas.drawBitmap(mChessBW[3], mStartX + (i) * GRID_WIDTH, mStartY + (j) * GRID_WIDTH, mPainttest2);

               }else if(mGridArray[i][j] == 7)
               {
                   paintCircle.setColor(Color.BLACK);
                   canvas.drawRect(mStartX+i*GRID_WIDTH, mStartY+j*GRID_WIDTH ,mStartX+(i+1)* GRID_WIDTH,mStartY +(j+1)* GRID_WIDTH, paintCircle);
               }
               else{paintCircle.setColor(Color.BLUE);
               }
               if(staticArray[i][j]==BLACK&&makeup==now_up)//移動時
               {

            	   canvas.drawBitmap(mChessBW[2], mStartX + (i) * GRID_WIDTH  , mStartY + (j)* GRID_WIDTH  , mPaint);

               }
               else if(staticArray[i][j]==WHITE&&makeup==now_up)
               {

            	   canvas.drawBitmap(mChessBW[1], mStartX + (i) * GRID_WIDTH, mStartY + (j) * GRID_WIDTH, mPaint2);

               }
               else if(staticArray[i][j]==3&&makeup==now_up)//疊到時
               {
            	   paintCircle.setColor(Color.DKGRAY);
                   canvas.drawRect(mStartX+(i)*GRID_WIDTH, mStartY+j*GRID_WIDTH ,mStartX+(i+1)* GRID_WIDTH,mStartY +(j+1)* GRID_WIDTH, paintCircle);

               }

               if(thirdArray[i][j]==BLACK&&makeup==now_up+1)
               {   parent.conquer_other=0;

               canvas.drawBitmap(mChessBW[2], mStartX + (i) * GRID_WIDTH  , mStartY + (j)* GRID_WIDTH  , mPaint);

               }
               else if(thirdArray[i][j]==WHITE&&makeup==now_up+1)
               {   parent.conquer_other=0;

               canvas.drawBitmap(mChessBW[1], mStartX + (i) * GRID_WIDTH, mStartY + (j) * GRID_WIDTH, mPaint2);

               }else if(thirdArray[i][j]==3&&makeup==now_up+1)//有疊到
               {   parent.conquer_other=1;
            	   paintCircle.setColor(Color.DKGRAY);
                   canvas.drawRect(mStartX+(i)*GRID_WIDTH, mStartY+j*GRID_WIDTH ,mStartX+(i+1)* GRID_WIDTH,mStartY +(j+1)* GRID_WIDTH, paintCircle);
                   if(ifending!=1)
                   {
                   Toast toast = Toast.makeText(parent, "can't conquer", Toast.LENGTH_SHORT);
     	             toast.show();
                   }
     	             parent.b.setEnabled(false);
               }

            }
        }
        for (int i = 0; i < GRID_SIZE-1; i++) {//整個邊框在繪一次
            for (int j = 0; j < GRID_SIZE-1; j++) {
                int mLeft = i * GRID_WIDTH + mStartX;
                int mTop = j * GRID_WIDTH + mStartY;
                int mRright = mLeft + GRID_WIDTH;
                int mBottom = mTop + GRID_WIDTH;
                canvas.drawRect(mLeft, mTop, mRright, mBottom, paintRect);
            }
        }
        paintRect.setStrokeWidth(10);//最外框
        canvas.drawRect(mStartX, mStartY, mStartX + GRID_WIDTH*(GRID_SIZE-1), mStartY + ( GRID_WIDTH*(GRID_SIZE-1)), paintRect);

        for(int i=0;i<GRID_SIZE-1;i++)
        {
        	for (int j = 0; j < GRID_SIZE-1; j++) {
                if(thirdArray[i][j]==3)
                	if_conquer=1;

        	}
        }
        if(if_conquer==0&&if_release==0)
        	parent.b.setEnabled(true);
    }


    public void putChess2(int x,int y,int blackwhite){
    	if(staticArray[x][y]==blackwhite)
    	{
    		staticArray[x][y]=blackwhite ;
    	}
    	else if(staticArray[x][y]==0)
    	{
    		staticArray[x][y]=blackwhite ;
    	}
    	else
    	{
    		staticArray[x][y]=3 ;
    	}

    }
    public void putChess3(int x,int y,int blackwhite){
    	if(thirdArray[x][y]==blackwhite)
    	{
    		thirdArray[x][y]=blackwhite;
    	}else if(thirdArray[x][y]==0)
    	{
    		thirdArray[x][y]=blackwhite;

    	}else
    	{
    		thirdArray[x][y]=3;
    	}
    }


    ///////整行滿，換色/////////
    public int check_x(int x)
    {
    	for( int i = 0 ; i < GRID_SIZE - 1 ; i++ )
    	{
    		if(thirdArray[x][i] == 0)
    		{
    			return 0 ;
    		}
    	}
    	return 1 ;
    }

    public int check_y(int y)
    {
    	for( int i = 0 ; i < GRID_SIZE - 1 ; i++ )
    	{
    		if(thirdArray[i][y] == 0)
    		{
    			return 0 ;
    		}
    	}
    	return 1 ;
    }

    public void draw_x(int x,int turn)
    {
    	for(int i = 0 ; i < GRID_SIZE - 1 ; i++ )
    	{
    		if(thirdArray[x][i]==7)
            	;
            else
        	  thirdArray[x][i] = turn ;
    	}
    }

    public void draw_y(int y,int turn)
    {
    	for(int i = 0 ; i < GRID_SIZE - 1 ; i++ )
    	{
    		if(thirdArray[i][y]==7)
            	;
        	else
               thirdArray[i][y] = turn ;
    	}
    }

    public void change_line(int x,int y,int temp[][],int turn)
    {
    	int xi , yi;
    	for(int i = 0 ; i < 5 ; i++ )
    	{
    		xi = x+temp[i][0] ;
    		yi = y+temp[i][1] ;
    		if(check_x(xi) == 1 && rowAndCol[1][xi] == 0)
    		{
                rowAndCol[1][xi] = 1 ;
    			draw_x(xi,turn) ;
    		}
    		if(check_y(yi) == 1 && rowAndCol[0][yi] == 0)
    		{
                rowAndCol[0][yi] = 1 ;
    			draw_y(yi,turn) ;
    		}
    	}
    }




    //-------------------------------------------------------------------------------------------------------------------------------------------------------


    int blockStorage[][][] = new int [4][5][2];
    int computer1;
    int computer2;
    int player1;
    int player2;
    int finalX=-1;
    int finalY=-1;
    int roundNumber=0;
    linear linearfunc = (linear)getContext(); //

    public void computerAIDifficult(){
        creatBlock();                                                   //取得這輪的所有方塊
        finalX=-1; finalY=-1;                                           //初始化座標位置
    if(ai_level==1)
    {
    	minimax(thirdArray, 0, 1, 2, rowAndCol);
    }else if(ai_level==2)
    {
    	minimax(thirdArray, 0, 1, 3, rowAndCol);
    }else if(ai_level==3)
    {    if(roundNumber<4) {//前4次先跑depth3 減少時間
           minimax(thirdArray, 0, 1, 3, rowAndCol);
         }
         else {
        	 minimax(thirdArray, 0, 1, 4, rowAndCol);
         }
    }

        if(finalX !=-1 && finalY!=-1) {                                 //若無位置可下的話結束
            putIn(thirdArray, finalX, finalY, 1,rowAndCol,true);          //放置方塊
        }
        else {
            Toast toast3 = Toast.makeText(linearfunc, "com has no Position", Toast.LENGTH_SHORT);
            toast3.show();
            ifending=1;
        }

        returnBlock();                                                 //回傳下一輪電腦方塊

        roundNumber++;
    }

    public void creatBlock() {

        shape comShape1 = new shape();                              //取出linear的第一個電腦方塊當now
        computer1=linearfunc.index_ai;
        comShape1.getShape_XY(computer1, blockStorage[0]);

        shape comShape2 = new shape();                              //新創一個電腦方塊當next
        computer2=comShape2.got_index();
        comShape2.getShape_XY(computer2, blockStorage[2]);

        shape playerShape1 = new shape();                           //取出linear的新產生的方塊當now
        player1=linearfunc.index;
        playerShape1.getShape_XY(player1, blockStorage[1]);

        shape playerShape2 = new shape();                           //新創一個玩家方塊當next
        player2=linearfunc.testindex;
        playerShape2.getShape_XY(player2, blockStorage[3]);
    }

    public void returnBlock(){
        linearfunc.index_ai=computer2;                               //將電腦方塊next 傳回linear當下一輪的電腦方塊now
    }

    public void resetTempArray(int [][]A,int [][]B){
        for(int x = 0; x < GRID_SIZE-1; x++){
            for(int y = 0; y < GRID_SIZE-1; y++){
                A[x][y]=B[x][y];
            }
        }
    }

    public boolean canPut(int [][] state ,int layer ,int axisX ,int axisY){

        int put;
        int count=0;
        put = (layer%2==0)? 1:2;

        for(int x=0;x<5;x++){
            if((axisX+blockStorage[layer-1][x][0]) < 0 || (axisX+blockStorage[layer-1][x][0]) > (GRID_SIZE-2) || (axisY+blockStorage[layer-1][x][1]) < 0 || (axisY+blockStorage[layer-1][x][1]) > (GRID_SIZE-2)){return false;}
            else{
                if(put == 1) {
                    if (state[axisX + blockStorage[layer-1][x][0]][axisY + blockStorage[layer-1][x][1]] == 1) {count++;}
                    else if (state[axisX + blockStorage[layer-1][x][0]][axisY + blockStorage[layer-1][x][1]] == 2
                            || state[axisX + blockStorage[layer-1][x][0]][axisY + blockStorage[layer-1][x][1]] == -2) {
                        return false;
                    }
                }
                else if(put == 2){
                    if (state[axisX + blockStorage[layer-1][x][0]][axisY + blockStorage[layer-1][x][1]] == 1) {return false;}
                    else if (state[axisX + blockStorage[layer-1][x][0]][axisY + blockStorage[layer-1][x][1]] == 2
                            || state[axisX + blockStorage[layer-1][x][0]][axisY + blockStorage[layer-1][x][1]] == -2) {
                        count++;
                    }
                }
            }
            //那格是黑的就不用算
            if (state[axisX + blockStorage[layer-1][x][0]][axisY + blockStorage[layer-1][x][1]] == 7) {return false;}
            
        }
        if(count == 5){return false;}

        return true;
    }

    public void changLineColor(int [][] state,int X,int Y,int color,int [][]tempChangeRowAndCol){
        int count=0;
        if(tempChangeRowAndCol[1][X]==0) {
            for (int i = 0; i < GRID_SIZE - 1; i++) {
                if (state[X][i] == 0) {break;}
                count++;
            }
            if (count == (GRID_SIZE - 1)) {
                for (int i = 0; i < GRID_SIZE - 1; i++) 
                {
                 if(state[X][i]==7)//那格是黑的
                	continue;
                 else
                	state[X][i] = color;
                 }
                    tempChangeRowAndCol[1][X]=1;
             }
          }
        if(tempChangeRowAndCol[0][Y]==0) {
            count = 0;
            for (int i = 0; i < GRID_SIZE - 1; i++) {
                if (state[i][Y] == 0) {break;}
                count++;
            }
            if (count == (GRID_SIZE - 1)) {
                for (int i = 0; i < GRID_SIZE - 1; i++) {
                    if(state[i][Y]==7)//那格是黑的
                    	continue;
                    else
                	  state[i][Y] = color;
                }
                tempChangeRowAndCol[0][Y]=1;
            }
        }

    } //col row要再確認

    public int minimax(int[][] lastState,int lastScore,int layer,int endLayer,int canChangeLine[][]){

        int returnScore;
        int score = 0;
        int tempStateArray[][] = new int[GRID_SIZE-1][GRID_SIZE-1];              //暫存棋盤面的陣列
        int tempChangeRowAndCol[][] = new int[2][GRID_SIZE-1];                   //暫存可換色的橫直排

        returnScore = (layer%2==0)?10000:-10000;                                 //依照最大最小層設定初始值 確保在第一層所有分數為0時 一定會紀錄第一個位置座標

        for( int x = 0; x < GRID_SIZE-1; x++){                                // 依照棋盤 高*寬 依序測試此位置能不能放
            for( int y = 0; y < GRID_SIZE-1; y++){

                for(int countX=0;countX<GRID_SIZE-1;countX++) {                         //將原始直線換色資料存入暫存陣列
                    tempChangeRowAndCol[0][countX] = rowAndCol[0][countX];
                    tempChangeRowAndCol[1][countX] = rowAndCol[1][countX];
                }

                resetTempArray(tempStateArray,lastState);                         //將暫存陣列設為上一個狀態

                if(canPut(tempStateArray,layer,x,y)) {                            // 可放為true 不可放為false
                    putIn(tempStateArray,x,y,layer,tempChangeRowAndCol,false);                             //確認可放後將方塊放入此位置    (可再修改  可和canPut合併)
                    score = getScore(tempStateArray,lastState,layer,tempChangeRowAndCol,canChangeLine);        //取得放置此位置後所得分數  依照最大效益 最大層為正分 最小層為負分
                    if(layer != endLayer) {                                 //層數到達最終層時不作遞迴
                        if(layer == endLayer-1){
                            if(returnScore < score){score = minimax(tempStateArray, score, layer+1,endLayer,tempChangeRowAndCol);}  //在最終層的前一層 若score 小於returnScore 則做剪枝
                        }
                        else {
                            score = minimax(tempStateArray, score, layer+1, endLayer,tempChangeRowAndCol);
                        }
                    }
                    if(layer % 2 == 1) {                                                 //最大層取所有中的最高分
                        if(returnScore < score) {
                            returnScore = score;
                            if(layer == 1) {finalX = x;finalY = y;}                      //只有在第一層時才做紀錄座標的動作
                        }
                    }
                    else{                                                           //最小層取所有中的最低分
                        if(returnScore > score){
                            returnScore = score;
                        }
                    }
                }
            }
        }
        return lastScore + returnScore;                                             //回傳上一層傳進來的分數和這層的分數總和
    }

    public void putIn(int [][]state,int axisX,int axisY,int layer,int [][]tempChangeRowAndCol,boolean truelyPut) {

        int blackOrWhite = (layer % 2 == 0) ? 1 : 2;
        boolean canChangeLine = true;
        for (int counterX = 0; counterX < 5; counterX++) {
            if (state[axisX + blockStorage[layer - 1][counterX][0]][axisY + blockStorage[layer - 1][counterX][1]] == blackOrWhite) {
                state[axisX + blockStorage[layer - 1][counterX][0]][axisY + blockStorage[layer - 1][counterX][1]] = blackOrWhite;
                canChangeLine = false;
            } else if (state[axisX + blockStorage[layer - 1][counterX][0]][axisY + blockStorage[layer - 1][counterX][1]] == 0) {
                state[axisX + blockStorage[layer - 1][counterX][0]][axisY + blockStorage[layer - 1][counterX][1]] = blackOrWhite;
                canChangeLine = true;
            } else {
                state[axisX + blockStorage[layer - 1][counterX][0]][axisY + blockStorage[layer - 1][counterX][1]] = 3;
            }
            if (canChangeLine) {
                changLineColor(state, axisX + blockStorage[layer - 1][counterX][0], axisY + blockStorage[layer - 1][counterX][1], blackOrWhite, tempChangeRowAndCol);
            }
        }

        if (truelyPut) {
            for (int counterX = 0; counterX < 5; counterX++) {
                    state[axisX + blockStorage[layer - 1][counterX][0]][axisY + blockStorage[layer - 1][counterX][1]] = -2;
            }
        }

    }

    public int getScore(int[][] nowState,int [][]lastState,int layer,int [][]nowRolAndCol,int [][]beforeRowAndCol){
        int score=0;
        int compareScore[] = new int [2];                                     //電腦0 玩家1
        compareScore[0]=0;compareScore[1]=0;

        int countScoreNow=0,countScoreLast=0;
        int whosTurn = (layer%2==0)? 1:2;
        for (int counterX = 0; counterX < GRID_SIZE - 1; counterX++) {
            for (int counterY = 0; counterY < GRID_SIZE - 1; counterY++) {

                if (nowState[counterX][counterY] == whosTurn) { countScoreNow++;}
                if (lastState[counterX][counterY] == whosTurn) { countScoreLast++;}

                if(nowState[counterX][counterY] == 1){compareScore[1]++;}
                else if(nowState[counterX][counterY] == 2){compareScore[0]++;}
            }
        }
        int countLine=0;
        for(int countX=0;countX<GRID_SIZE-1;countX++){
            if(nowRolAndCol[0][countX]==1 && beforeRowAndCol[0][countX]==0){countLine++;}
            if(nowRolAndCol[1][countX]==1 && beforeRowAndCol[1][countX]==0){countLine++;}
        }

        score += countLine * 1000;
        score += (countScoreNow-countScoreLast)*10;
        score *= (layer%2==0)? -1 : 1;
if(layer<4) {
    if (score < 0) {                                                                                 //避免發生在自己分數低於對手時下了結束遊戲的一步
        if (compareScore[0] > compareScore[1]) {                               //在最小層的狀況
            if (checkEnd(layer + 1, nowState)) {
                score += 10000;
            }
        }
    } else {                                                                                           //再最大層的狀況
        if (compareScore[0] < compareScore[1]) {
            if (checkEnd(layer + 1, nowState)) {
                score -= 10000;
            }
        }

    }
}
        return score;
    }

    public boolean checkEnd(int layer,int [][]nowState){//檢查玩家是否可放  不可放的情況則結束遊戲   再檢查

        for(int counterX=0;counterX<GRID_SIZE-1;counterX++){
            for (int counterY=0;counterY<GRID_SIZE-1;counterY++){
                if(canPut(nowState,layer,counterX,counterY)){return false;}
            }
        }
        return true;
    }

    //------------------------------------------------------------------------------------------------------------------------------------------------------------------

    public void init_maps()
    {
        linear parent = (linear)getContext();
        maps M = new maps() ;
        
        //int index =(int)(Math.random()*13);
        //int index =chooseLevel;
        int index= Integer.valueOf(parent.name_level);//第幾關
         
        int map [] = new int [M.mapAi[index].length];
        
        M.get_maps_ai(map,index);
        for(int i = 0 ; i <= map.length-1 ; i++ )
        {
            mGridArray[map[i]%GRID_SIZE][map[i]/GRID_SIZE] = 7 ;
        }
        this.invalidate();
        Toast toast = Toast.makeText(parent, index + " ", Toast.LENGTH_SHORT);
        toast.show();
    }
    public void spec_maps()
    {
    	 linear parent = (linear)getContext();
    	 int index= Integer.valueOf(parent.name_level);//第幾關
    	 //41 42 43 (level 42 43 44)
    		  int x,tensx;//隨機產生位子

    	 Random ran = new Random();
    	 if(index==33)
    	 {
    		 x=ran.nextInt(9);
    		 tensx=ran.nextInt(9);
    		 mGridArray[tensx][x] = 7 ;
    	 }else if(index==34)
    	 {
    		 for(int i=0;i<4;i++)
    		 {
    			 x=ran.nextInt(9);
        		 tensx=ran.nextInt(9);
        		 mGridArray[tensx][x] = 7 ;
    		 }
    	 }
    	 this.invalidate();
    }
    ////////////////////////////////////////
    public void showTextView(CharSequence mT){
        this.mStatusTextView.setText(mT);
        mStatusTextView.setVisibility(View.VISIBLE);

    }
    public void finish_score(){
   	 
    	for( int i = 0 ; i < GRID_SIZE -1 ; i++ )
        {
            for( int j = 0 ; j < GRID_SIZE-1 ; j++ )
            {
               if(mGridArray[i][j]==1)
            	   playerScore++;
               else if(mGridArray[i][j]==2)
            	   aiScore++;
            }
        }
    	linear parent = (linear)getContext();
    	parent.ending();
    }
}
