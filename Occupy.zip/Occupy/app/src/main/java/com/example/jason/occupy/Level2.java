package com.example.jason.occupy;


import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.Toast;


public class Level2 extends Fragment {
		//高級
		private View v;
		private GridView gridView;
		private int[] image = {
				 R.drawable.orangeafter16,
		            R.drawable.orangeafter17, R.drawable.orangeafter18,
		            R.drawable.orangeafter19, R.drawable.orangeafter20,
		            R.drawable.orangeafter21, R.drawable.orangeafter22,
		            R.drawable.orangeafter23, R.drawable.orangeafter24,
		            R.drawable.orangeafter25, R.drawable.orangeafter26,
		            R.drawable.orangeafter27, R.drawable.orangeafter28,
		            R.drawable.orangeafter29, R.drawable.orangeafter30
	    };
		@Override
		public void onAttach(Activity activity) {
			super.onAttach(activity);

			//BeforeLevel mainActivity = (BeforeLevel)activity;
			//value = mainActivity.getAppleData();
		}
		private String[] imgText = {
	            "1", "2", "3", "4", "5", "6", "7", "8","9","10","11","12","13","14",
	            "15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30"
	    };
		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {

			 v=inflater.inflate(R.layout.level_choose2, container, false);
			 GridView gridview = (GridView) v.findViewById(R.id.gridViewLevel2);
			 gridview.setAdapter(new ImageAdapterLevel2(getActivity()));
			 gridview.setOnItemClickListener(new OnItemClickListener() {
		            public void onItemClick(AdapterView<?> parent, View v,
		                    int position, long id) {
		            	 Intent it= new Intent();
		            	 if(position==0)
			                {	//background.setBackgroundColor(Color.GREEN);

								it.setClass(getActivity(),DoubleManHard.class);
								it.putExtra("leve","0");
								it.putExtra("widt","10");
								startActivity(it);
								getActivity().finish();
			                }else if(position==1)
			                {
								it.setClass(getActivity(),DoubleManHard.class);
								it.putExtra("leve","1");
								it.putExtra("widt", "10");
								startActivity(it);
								getActivity().finish();
			                }
			                else if(position==2)
			                {	//background.setBackgroundColor(Color.BLUE);
			                	it.setClass(getActivity(),DoubleManHard.class);
								it.putExtra("leve","2");
								it.putExtra("widt","10");
								startActivity(it);
								getActivity().finish();
			                }else if(position==3)
			                {
								it.setClass(getActivity(),DoubleManHard.class);
								it.putExtra("leve","3");
								it.putExtra("widt","10");
								startActivity(it);
								getActivity().finish();
			                }else if(position==4)
			                {
								it.setClass(getActivity(),DoubleManHard.class);
								it.putExtra("leve","4");
								it.putExtra("widt","10");
								startActivity(it);
								getActivity().finish();
			                }else if(position==5)
			                {
								it.setClass(getActivity(),DoubleManHard.class);
								it.putExtra("leve","5");
								it.putExtra("widt", "10");
								startActivity(it);
								getActivity().finish();
			                }else if(position==6)
			                {
								it.setClass(getActivity(),DoubleManHard.class);
								it.putExtra("leve","6");
								it.putExtra("widt", "10");
								startActivity(it);
								getActivity().finish();
			                }else if(position==7)
			                {
								it.setClass(getActivity(),DoubleManHard.class);
								it.putExtra("leve","7");
								it.putExtra("widt", "10");
								startActivity(it);
								getActivity().finish();
								//Level2.this.finish();
			                }else if(position==8)
			                {
								it.setClass(getActivity(),DoubleManHard.class);
								it.putExtra("leve","8");
								it.putExtra("widt", "10");
								startActivity(it);
								getActivity().finish();
			                }else if(position==9)
			                {
								it.setClass(getActivity(),DoubleManHard.class);
								it.putExtra("leve","9");
								it.putExtra("widt", "10");
								startActivity(it);
								getActivity().finish();
			                }else if(position==10)
			                {
								it.setClass(getActivity(),DoubleManHard.class);
								it.putExtra("leve","10");
								startActivity(it);
								getActivity().finish();
			                }else if(position==11)
			                {
								it.setClass(getActivity(),DoubleManHard.class);
								it.putExtra("leve","11");
								startActivity(it);
								getActivity().finish();
			                }else if(position==12)
			                {
								it.setClass(getActivity(),DoubleManHard.class);
								it.putExtra("leve","12");
								startActivity(it);
								getActivity().finish();
			                }else if(position==13)
			                {
								it.setClass(getActivity(),DoubleManHard.class);
								it.putExtra("leve","13");
								startActivity(it);
								getActivity().finish();
			                }else if(position==14)
			                {
								it.setClass(getActivity(),DoubleManHard.class);
								it.putExtra("leve","14");
								startActivity(it);
								getActivity().finish();
			                }
		            }
			 });
			 return v;
		}
		/*protected void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        //requestWindowFeature(Window.FEATURE_NO_TITLE);//去除標題列
	        setContentView(R.layout.level_choose2);
	        GridView gridview = (GridView) findViewById(R.id.gridViewLevel2);
	        gridview.setAdapter(new ImageAdapterLevel2(this));

	        gridview.setOnItemClickListener(new OnItemClickListener() {
	            public void onItemClick(AdapterView<?> parent, View v,
	                    int position, long id) {
	                
	                Intent it= new Intent();
	                if(position==0)
	                {	//background.setBackgroundColor(Color.GREEN);
	                	
						it.setClass(Level2.this,DoubleManHard.class);
						it.putExtra("leve","0");
						it.putExtra("widt","10");
						startActivity(it);
						Level2.this.finish();
	                }else if(position==1)
	                {	
						it.setClass(Level2.this,DoubleManHard.class);
						it.putExtra("leve","1");
						it.putExtra("widt", "10");
						startActivity(it);
						Level2.this.finish();
	                }
	                else if(position==2)
	                {	//background.setBackgroundColor(Color.BLUE);
	                	it.setClass(Level2.this,DoubleManHard.class);
						it.putExtra("leve","2");
						it.putExtra("widt","10");
						startActivity(it);
						Level2.this.finish();
	                }else if(position==3)
	                {	
						it.setClass(Level2.this,DoubleManHard.class);
						it.putExtra("leve","3");
						it.putExtra("widt","10");
						startActivity(it);
						Level2.this.finish();
	                }else if(position==4)
	                {	
						it.setClass(Level2.this,DoubleManHard.class);
						it.putExtra("leve","4");
						it.putExtra("widt","10");
						startActivity(it);
						Level2.this.finish();
	                }else if(position==5)
	                {	
						it.setClass(Level2.this,DoubleManHard.class);
						it.putExtra("leve","5");
						it.putExtra("widt", "10");
						startActivity(it);
						Level2.this.finish();
	                }else if(position==6)
	                {	
						it.setClass(Level2.this,DoubleManHard.class);
						it.putExtra("leve","6");
						it.putExtra("widt", "10");
						startActivity(it);
						Level2.this.finish();
	                }else if(position==7)
	                {	
						it.setClass(Level2.this,DoubleManHard.class);
						it.putExtra("leve","7");
						it.putExtra("widt", "10");
						startActivity(it);
						Level2.this.finish();
	                }else if(position==8)
	                {	
						it.setClass(Level2.this,DoubleManHard.class);
						it.putExtra("leve","8");
						it.putExtra("widt", "10");
						startActivity(it);
						Level2.this.finish();
	                }else if(position==9)
	                {	
						it.setClass(Level2.this,DoubleManHard.class);
						it.putExtra("leve","9");
						it.putExtra("widt", "10");
						startActivity(it);
						Level2.this.finish();
	                }
	            }
	        });
	        
		
	       
	        
		}*/
		
		@Override
		public void onActivityCreated(Bundle savedInstanceState) {
			super.onActivityCreated(savedInstanceState);
			Log.d("=====>", "AppleFragment onActivityCreated");
			// GridView gridview = (GridView) this.getView().findViewById(R.id.gridViewLevel);
		     //   gridview.setAdapter(new ImageAdapterLevel(this));
		       
			//TextView txtResult = (TextView) this.getView().findViewById(R.id.textView1);
			//txtResult.setText(value);
		}

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
