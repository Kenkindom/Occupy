package com.example.jason.occupy;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by user on 2015/8/3.
 */
public class Double_view_hard extends View {
    public static int GRID_SIZE = 13;
    protected int GRID_WIDTH =70;
    protected static int CHESS_DIAMETER = 26; // 棋的直?
    protected static int mStartX;// 棋?定位的左上角X
    protected static int mStartY;// 棋?定位的左上角Y

    private Bitmap[] mChessBW; // 黑棋和白棋
    private static int[][] mGridArray; // 网格
    private static int[][] staticArray;
    private static int[][] thirdArray;
    private static int[] row;
    private static int[] col;

    boolean key = false;

    Double_view2_hard s;

    int shape[][] = new int[5][2];//目前圖形
    int score[] = new int[2] ;
    int score_plus ;//紀錄目前某方得到的分數
    int turn = 0 ;
    int wbflag = 1; //?下白棋了=2，?下黑棋了=1. ?里先下黑棋（黑棋以后?置?机器自?下的棋子）
    int mLevel = 1; //游??度
    int mWinFlag = 0;
    int makeup=1;//按的次數
    int now_up=makeup;
    int x;
    int y;
    int if_conquer=0,if_release=0,blank;
    private final int BLACK=1;
    private final int WHITE=2;
    public static int player1Score=0,player2Score=0;//算最後雙方有幾格
    public static int ifending=0;//是否結束

    int mGameState = GAMESTATE_RUN; //游??段：0=尚未游?，1=正在?行游?，2=游??束
    static final int GAMESTATE_PRE = 0;
    static final int GAMESTATE_RUN = 1;
    static final int GAMESTATE_PAUSE = 2;
    static final int GAMESTATE_END = 3;

    //private TextView mStatusTextView; //  根据游????置?示的文字
    public TextView mStatusTextView; //  根据游????置?示的文字
    //public TextView order;
    private Bitmap btm1;
    private final Paint mPaint = new Paint();

    CharSequence mText;
    CharSequence STRING_WIN = "White win! /n Press Fire Key to start new game.";
    CharSequence STRING_LOSE = "Black win! /n Press Fire Key to start new game.";
    CharSequence STRING_EQUAL = "Cool! You are equal! /n Press Fire Key to start new Game.";

    public Double_view_hard(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    public Double_view_hard(Context context, AttributeSet attrs) { //好像?用的是??构造函?，?什么不是前面的呢
        super(context, attrs);
        this.setFocusable(true);  //20090530
        this.setFocusableInTouchMode(true);
        // order=(TextView)findViewById(R.id.set);
        //GRID_WIDTH=metrics.widthPixels; // 棋?格的?度
        init();
    }


    //?里?棋子后??有用?片?，而是直接?了?。因?我做的?片不好看。
    // 初始化黑白棋的Bitmap
    public void init() {
        mGameState = 1; //?置游???始??
        wbflag = BLACK; //初始?先下黑棋
        mWinFlag = 0; //清空???志。
        mGridArray = new int[GRID_SIZE-1][GRID_SIZE-1];
        staticArray = new int[GRID_SIZE-1][GRID_SIZE-1];
        thirdArray=new int[GRID_SIZE-1][GRID_SIZE-1];
        row = new int [GRID_SIZE-1];
        col = new int [GRID_SIZE-1];
        score[0] = 0;
        score[1] = 0;
        turn = 1 ;
        blank = 0;


        for(int i=0;i<GRID_SIZE-1;i++)
        {
            for(int j=0;j<GRID_SIZE-1;j++)
            {
                staticArray[i][j]=0;
                thirdArray[i][j]=0;
            }
        }


        mChessBW = new Bitmap[3];
        s = (Double_view2_hard)this.findViewById(R.id.view2_double_hard);//不確定要不要
        Bitmap bitmap = Bitmap.createBitmap(CHESS_DIAMETER, CHESS_DIAMETER, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        Resources r = this.getContext().getResources();


    }


    public void setTextView(TextView tv){
        mStatusTextView =tv;
        mStatusTextView.setVisibility(View.INVISIBLE);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        mStartX = w/(GRID_SIZE+1);//1080 1360 0 0
        mStartY =  h/(GRID_SIZE+1);
        GRID_WIDTH=w/(GRID_SIZE+1);
        CHESS_DIAMETER=w/(GRID_SIZE+1);
        super.onSizeChanged(w, h, oldw, oldh);
        Log.e("abc", "onSizeChanged,w=" + mStartX + ",h=" + mStartY + ",oldw=" + GRID_WIDTH + ",oldh=" + CHESS_DIAMETER);
    }

    public void check_bound(int temp[][],int x,int y)
    {
        int up=0,down=0,left=0,right=0,just_x=0,just_y=0;

        for(int i = 0 ; i < 5 ; i++ )
        {
            if(x+temp[i][0] < 0)
            {
                up = 1 ;
                just_x = 1 ;
                break ;
            }
            else if(x+temp[i][0] >= GRID_SIZE-1)
            {
                down = 1 ;
                just_x = -1 ;
                break ;
            }
            else if(y+temp[i][1] < 0)
            {
                left = 1 ;
                just_y = 1 ;
                break ;
            }
            else if(y+temp[i][1] >= GRID_SIZE-1)
            {
                right = 1 ;
                just_y = -1 ;
                break ;
            }
        }

        if( up==1 || down==1 || left==1 || right==1 )
        {
            for(int i = 0;i < 5;i++)
            {
                temp[i][0] += just_x ;
                temp[i][1] += just_y ;
            }
            check_bound(temp,x,y) ;
        }
        else
        {
            return ;
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event){
        switch (mGameState) {
            case GAMESTATE_PRE:
                break;
            case GAMESTATE_RUN: {

                float x1=event.getX();
                float y1=event.getY();
                float x0 = GRID_WIDTH - (event.getX() - mStartX) % GRID_WIDTH;
                float y0 = GRID_WIDTH - (event.getY() - mStartY) % GRID_WIDTH;
                x = (int) ((event.getX() - mStartX) / GRID_WIDTH) ;//點的X位子
                y = (int) ((event.getY() - mStartY) / GRID_WIDTH) ;
                shape temp_shape = new shape() ;
                DoubleManHard parent = (DoubleManHard)getContext(); // I meant this line

                int index = parent.getImportantInt();
                int index2=parent.getImportantInt2();
                wbflag = parent.getturn();

                switch(event.getAction())
                {
                    case MotionEvent.ACTION_DOWN:
                    	if(ifending==1){//結束時
                    		finish_score();
                            Toast toast222 = Toast.makeText(parent, "" + player1Score + "and" + player2Score, Toast.LENGTH_SHORT);
                            toast222.show();
                            parent.ending();
                            ifending=0;
                    	}
                        now_up=makeup;
                        if(wbflag==BLACK)
                        	temp_shape.getShape_XY(index, shape);
                        else if(wbflag==WHITE)
                        	temp_shape.getShape_XY(index2, shape);
                        check_bound(shape,x,y);
                        mText="index: "+ String.format("%d\n", index)+
                                "tempx1: "+ String.format("%d", thirdArray[0][0])+
                                "tempy1: "+ String.format("%d\n", thirdArray[0][1])+
                                "tempx2: "+ String.format("%d", thirdArray[0][2])+
                                "tempy2: "+ String.format("%d\n", thirdArray[0][3])+
                                "tempx3: "+ String.format("%d", shape[2][0])+
                                "tempy3: "+ String.format("%d\n", shape[2][1])+
                                "tempx4: "+ String.format("%d", shape[3][0])+
                                "tempy4: "+ String.format("%d\n", shape[3][1])+
                                "tempx5: "+ String.format("%d", shape[4][0])+
                                "tempy5: "+ String.format("%d\n", shape[4][1])+
                                "X: "+ String.format("%d\n", x)+
                                "Y: " + String.format("%d", y);
                        //showTextView(mText);
                        for(int i = 0 ; i < GRID_SIZE-1 ; i++ )//GRID_SIZE=10
                        {
                            for(int j = 0 ; j < GRID_SIZE-1 ; j++ )
                            {
                                staticArray[i][j] = mGridArray[i][j];//存進去
                            }
                        }
                        if ((x >= 0 && x < GRID_SIZE - 1) && (y >= 0 && y < GRID_SIZE - 1))
                        {
                            if (mGridArray[x][y] == 0||mGridArray[x][y] == 1||mGridArray[x][y] == 2)
                            {
                                if (wbflag == BLACK)
                                {
                                    for( int i = 0 ; i < 5 ; i++)
                                    {
                                        putChess2(x+shape[i][0], y+shape[i][1], BLACK);
                                    }
                                }
                                else if (wbflag == WHITE)
                                {
                                    for( int i = 0 ; i < 5 ; i++)
                                    {
                                        putChess2(x+shape[i][0], y+shape[i][1], WHITE);
                                    }
                                }

                            }
                        }
                        break;
                    case MotionEvent.ACTION_UP:
                        makeup++;


                        for(int i = 0 ; i < GRID_SIZE-1 ; i++ )
                        {
                            for(int j = 0 ; j < GRID_SIZE-1 ; j++ )
                            {
                                //staticArray[i][j] = mGridArray[i][j]  ;
                                thirdArray[i][j]=mGridArray[i][j];
                                if(thirdArray[i][j]!=3)//寫在這會是在按確定後下個才回出現 所以不能寫這
                                {
                                    //Toast toast = Toast.makeText( parent, "can't conquer", Toast.LENGTH_SHORT);
                                    // toast.show();
                                    if_conquer=0;
                                }
                            }
                        }
                        check_bound(shape,x,y);
                        if ((x >= 0 && x < GRID_SIZE - 1) && (y >= 0 && y < GRID_SIZE - 1))
                        {
                            if (mGridArray[x][y] == 0 ||mGridArray[x][y] == 1||mGridArray[x][y] == 2)
                            {
                                if (wbflag == BLACK)
                                {
                                    for( int i = 0 ; i < 5 ; i++)
                                    {
                                        putChess3(x+shape[i][0], y+shape[i][1], BLACK);//上面的格子
                                    }

                                    turn = 2 ;
                                    wbflag = WHITE;
                                }
                                else if (wbflag == WHITE)
                                {
                                    for( int i = 0 ; i < 5 ; i++)
                                    {
                                        putChess3(x+shape[i][0], y+shape[i][1], WHITE);
                                    }
                                    turn = 1 ;
                                    wbflag = BLACK;
                                }
                            }
                        }
                        break;
                    case MotionEvent.ACTION_MOVE:
                        now_up=makeup;
                        for(int i = 0 ; i < GRID_SIZE-1 ; i++ )
                        {
                            for(int j = 0 ; j < GRID_SIZE-1 ; j++ )
                            {
                                staticArray[i][j] = mGridArray[i][j]  ;
                            }
                        }
                        check_bound(shape,x,y);
                        if ((x >= 0 && x < GRID_SIZE - 1) && (y >= 0 && y < GRID_SIZE - 1))
                        {
                            if (mGridArray[x][y] == 0||mGridArray[x][y] == 1||mGridArray[x][y] == 2)
                            {
                                if (wbflag == BLACK)
                                {
                                    for( int i = 0 ; i < 5 ; i++)
                                    {
                                        putChess2(x+shape[i][0], y+shape[i][1], BLACK);
                                    }
                                }
                                else if (wbflag == WHITE)
                                {
                                    for( int i = 0 ; i < 5 ; i++)
                                    {
                                        putChess2(x+shape[i][0], y+shape[i][1], WHITE);
                                    }
                                }
                            }
                        }
                        break;
                    default:
                        break;
                }


            }

            break;
            case GAMESTATE_PAUSE:
                break;
            case GAMESTATE_END:
                break;
        }

        this.invalidate();
        return true;

    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent msg) {
       // Log.e("KeyEvent.KEYCODE_DPAD_CENTER", " " + keyCode);

        if(keyCode == KeyEvent.KEYCODE_DPAD_CENTER){
            switch(mGameState){
                case GAMESTATE_PRE:
                    break;
                case GAMESTATE_RUN:
                    break;
                case GAMESTATE_PAUSE:
                    break;
                case GAMESTATE_END:
                {//游??束后，按CENTER???

                    Log.e("Fire Key Pressed:::", "FIRE");
                    mGameState = GAMESTATE_RUN;
                    this.setVisibility(View.VISIBLE);
                    this.mStatusTextView.setVisibility(View.INVISIBLE);
                    this.init();
                    this.invalidate();
                }
                break;
            }
        }

        return super.onKeyDown(keyCode, msg);
    }

    @Override
    public void onDraw(Canvas canvas) {

        canvas.drawColor(getResources().getColor(R.color.red_player_light));

        Bitmap bitmap = Bitmap.createBitmap(CHESS_DIAMETER, CHESS_DIAMETER, Bitmap.Config.ARGB_8888);
        Canvas canvas2 = new Canvas(bitmap);
        Resources r = this.getContext().getResources();

        Drawable tile = r.getDrawable(R.drawable.red);
        tile.setBounds(0, 0, CHESS_DIAMETER, CHESS_DIAMETER);//26X26
        tile.draw(canvas2);
        mChessBW[0] = bitmap;

        Drawable tile2 = r.getDrawable(R.drawable.green);
        tile2.setBounds(0, 0, CHESS_DIAMETER, CHESS_DIAMETER);
        tile2.draw(canvas2);
        mChessBW[1] = bitmap;

        Drawable tile3 = r.getDrawable(R.drawable.black);
        tile3.setBounds(0, 0, CHESS_DIAMETER, CHESS_DIAMETER);
        tile3.draw(canvas2);
        mChessBW[2] = bitmap;

        // ?棋?

        Paint paintRect = new Paint();
        paintRect.setColor(Color.RED);
        paintRect.setStrokeWidth(2);//float
        paintRect.setStyle(Paint.Style.STROKE);

        for (int i = 0; i < GRID_SIZE-1; i++) {
            for (int j = 0; j < GRID_SIZE-1; j++) {
                int mLeft = i * GRID_WIDTH + mStartX;
                int mTop = j * GRID_WIDTH + mStartY;
                int mRright = mLeft + GRID_WIDTH;
                int mBottom = mTop + GRID_WIDTH;
                canvas.drawRect(mLeft, mTop, mRright, mBottom, paintRect);
            }
        }

        //?棋?的外?框
        paintRect.setStrokeWidth(10);
        canvas.drawRect(mStartX, mStartY, mStartX + GRID_WIDTH*(GRID_SIZE-1), mStartY + ( GRID_WIDTH*(GRID_SIZE-1)), paintRect);

        DoubleManHard parent = (DoubleManHard)getContext();//取的parent的請求
        int answer=parent.getAnswer();
        if(answer==0)
        {

            for(int i = 0 ; i < GRID_SIZE-1 ; i++ )
            {
                for(int j = 0 ; j < GRID_SIZE-1 ; j++ )
                {
                    mGridArray[i][j]=thirdArray[i][j];
                }
            }
            for(int i = 0 ; i < GRID_SIZE-1 ; i++ )
            {
                for(int j = 0 ; j < GRID_SIZE-1 ; j++ )
                {
                    mGridArray[i][j]=thirdArray[i][j];
                }
            }
        }
        //?棋子
        paintRect.setStrokeWidth(2);
        for (int i = 0; i <GRID_SIZE-1; i++) {
            for (int j = 0; j <GRID_SIZE-1; j++) {
                Paint paintCircle = new Paint();
                paintCircle.setStrokeWidth(2);
                if(mGridArray[i][j]== BLACK)//非0就畫
                {
                    //canvas.drawBitmap(mChessBW[0], mStartX + (i) * GRID_WIDTH  , mStartY + (j)* GRID_WIDTH  , mPaint);
                    paintCircle.setColor(Color.YELLOW);
                    canvas.drawRect(mStartX+(i)*GRID_WIDTH, mStartY+j*GRID_WIDTH ,mStartX+(i+1)* GRID_WIDTH,mStartY +(j+1)* GRID_WIDTH, paintCircle);
                }
                else if(mGridArray[i][j] == WHITE)
                {
                    //canvas.drawBitmap(mChessBW[1], mStartX + (i) * GRID_WIDTH, mStartY + (j) * GRID_WIDTH, mPaint);
                  paintCircle.setColor(Color.GREEN);
                    canvas.drawRect(mStartX+i*GRID_WIDTH, mStartY+j*GRID_WIDTH ,mStartX+(i+1)* GRID_WIDTH,mStartY +(j+1)* GRID_WIDTH, paintCircle);
                }
                else if(mGridArray[i][j] == 7)
                {
                    paintCircle.setColor(Color.BLACK);
                    canvas.drawRect(mStartX+i*GRID_WIDTH, mStartY+j*GRID_WIDTH ,mStartX+(i+1)* GRID_WIDTH,mStartY +(j+1)* GRID_WIDTH, paintCircle);
                }
                else{paintCircle.setColor(Color.BLUE);
                }
                if(staticArray[i][j]==BLACK&&makeup==now_up)
                {
                    paintCircle.setColor(Color.YELLOW);//改WHITE會衝到
                    canvas.drawRect(mStartX+(i)*GRID_WIDTH, mStartY+j*GRID_WIDTH ,mStartX+(i+1)* GRID_WIDTH,mStartY +(j+1)* GRID_WIDTH, paintCircle);
                   // canvas.drawBitmap(mChessBW[0], mStartX + (i) * GRID_WIDTH  , mStartY + (j)* GRID_WIDTH  , mPaint);
                }
                else if(staticArray[i][j]==WHITE&&makeup==now_up)
                {
                    paintCircle.setColor(Color.GREEN);
                    canvas.drawRect(mStartX + (i) * GRID_WIDTH, mStartY + j * GRID_WIDTH, mStartX + (i + 1) * GRID_WIDTH, mStartY + (j + 1) * GRID_WIDTH, paintCircle);
                    //canvas.drawBitmap(mChessBW[1], mStartX + (i) * GRID_WIDTH  , mStartY + (j)* GRID_WIDTH  , mPaint);
                }
                else if(staticArray[i][j]==3&&makeup==now_up)//疊到時
                {
                    paintCircle.setColor(Color.DKGRAY);
                    canvas.drawRect(mStartX+(i)*GRID_WIDTH, mStartY+j*GRID_WIDTH ,mStartX+(i+1)* GRID_WIDTH,mStartY +(j+1)* GRID_WIDTH, paintCircle);
                    //canvas.drawBitmap(mChessBW[2], mStartX + (i) * GRID_WIDTH  , mStartY + (j)* GRID_WIDTH  , mPaint);
                }

                if(thirdArray[i][j]==BLACK&&makeup==now_up+1)
                {   parent.conquer_other=0;
                    paintCircle.setColor(Color.YELLOW);//改WHITE會衝到
                    canvas.drawRect(mStartX+(i)*GRID_WIDTH, mStartY+j*GRID_WIDTH ,mStartX+(i+1)* GRID_WIDTH,mStartY +(j+1)* GRID_WIDTH, paintCircle);
                    //canvas.drawBitmap(mChessBW[0], mStartX + (i) * GRID_WIDTH  , mStartY + (j)* GRID_WIDTH  , mPaint);
                }
                else if(thirdArray[i][j]==WHITE&&makeup==now_up+1)
                {   parent.conquer_other=0;
                    paintCircle.setColor(Color.GREEN);
                    canvas.drawRect(mStartX+(i)*GRID_WIDTH, mStartY+j*GRID_WIDTH ,mStartX+(i+1)* GRID_WIDTH,mStartY +(j+1)* GRID_WIDTH, paintCircle);
                    //canvas.drawBitmap(mChessBW[1], mStartX + (i) * GRID_WIDTH  , mStartY + (j)* GRID_WIDTH  , mPaint);
                }else if(thirdArray[i][j]==3&&makeup==now_up+1)//有疊到
                {   parent.conquer_other=1;
                    paintCircle.setColor(Color.DKGRAY);
                    canvas.drawRect(mStartX+(i)*GRID_WIDTH, mStartY+j*GRID_WIDTH ,mStartX+(i+1)* GRID_WIDTH,mStartY +(j+1)* GRID_WIDTH, paintCircle);
                    //canvas.drawBitmap(mChessBW[2], mStartX + (i) * GRID_WIDTH  , mStartY + (j)* GRID_WIDTH  , mPaint);
                    Toast toast = Toast.makeText(parent, "can't conquer", Toast.LENGTH_SHORT);
                    toast.show();
                    parent.b.setEnabled(false);
                }

            }
        }
        for (int i = 0; i < GRID_SIZE-1; i++) {//整個邊框在繪一次
            for (int j = 0; j < GRID_SIZE-1; j++) {
                int mLeft = i * GRID_WIDTH + mStartX;
                int mTop = j * GRID_WIDTH + mStartY;
                int mRright = mLeft + GRID_WIDTH;
                int mBottom = mTop + GRID_WIDTH;
                canvas.drawRect(mLeft, mTop, mRright, mBottom, paintRect);
            }
        }
        for(int i=0;i<GRID_SIZE-1;i++)
        {
            for (int j = 0; j < GRID_SIZE-1; j++) {
                if(thirdArray[i][j]==3)
                    if_conquer=1;

            }
        }
        if(if_conquer==0&&if_release==0)
            parent.b.setEnabled(true);
    }

    public void putChess(int x, int y, int blackwhite){
        mGridArray[x][y] = blackwhite;
    }
    public void putChess2(int x,int y,int blackwhite){
        if(staticArray[x][y]==blackwhite)
        {
            staticArray[x][y]=blackwhite ;
        }
        else if(staticArray[x][y]==0)
        {
            staticArray[x][y]=blackwhite ;
        }
        else
        {
            staticArray[x][y]=3 ;
        }

    }
    public void putChess3(int x,int y,int blackwhite){
        if(thirdArray[x][y]==blackwhite)
        {
            thirdArray[x][y]=blackwhite;
        }else if(thirdArray[x][y]==0)
        {
            thirdArray[x][y]=blackwhite;
            blank++ ;
        }else
        {
            thirdArray[x][y]=3;
        }
    }

    ///////整行滿，換色/////////
    public int check_x(int x)
    {
        for( int i = 0 ; i < GRID_SIZE - 1 ; i++ )
        {
            if(thirdArray[x][i] == 0 )
            {
                return 0 ;
            }
        }
        return 1 ;
    }

    public int check_y(int y)
    {
        for( int i = 0 ; i < GRID_SIZE - 1 ; i++ )
        {
            if(thirdArray[i][y] == 0 )
            {
                return 0 ;
            }
        }
        return 1 ;
    }

    public void draw_x(int x,int turn)
    {
        for(int i = 0 ; i < GRID_SIZE - 1 ; i++ )
        {
            if(thirdArray[x][i]==7)
            	;
            else
        	  thirdArray[x][i] = turn ;

        }
    }

    public void draw_y(int y,int turn)
    {
        for(int i = 0 ; i < GRID_SIZE - 1 ; i++ )
        {
        	if(thirdArray[i][y]==7)
            	;
        	else
               thirdArray[i][y] = turn ;
        }
    }

    public void change_line(int x,int y,int temp[][],int turn)
    {
        int xi , yi;
        for(int i = 0 ; i < 5 ; i++ )
        {
            xi = x+temp[i][0] ;
            yi = y+temp[i][1] ;
            if(check_x(xi) == 1 && col[xi] == 0)
            {
                col[xi] = 1 ;
                draw_x(xi,turn) ;
            }
            if(check_y(yi) == 1 && row[yi] == 0)
            {
                row[yi] = 1 ;
                draw_y(yi,turn) ;
            }
        }
    }

    public int finish(int turn,int index)
    {
        int temp [][] = new int [5][2] ;
        shape temp_shape = new shape() ;
        temp_shape.getShape_XY(index, temp);
        int empty = 0 ;

        for( int i = 0 ; i < GRID_SIZE -1 ; i++ )
        {
            for( int j = 0 ; j < GRID_SIZE-1 ; j++ )
            {
                empty = 0 ;
                for( int k = 0 ; k < 5 ; k++ )
                {

                    if( i + temp[k][0] < 0 || i + temp[k][0] >= GRID_SIZE-1 || j + temp[k][1] < 0 || j + temp[k][1] >= GRID_SIZE-1)
                    {
                        break ;
                    }

                    if(thirdArray[i+temp[k][0]][j+temp[k][1]] == 0 || thirdArray[i+temp[k][0]][j+temp[k][1]] == turn)
                    {
                        if(thirdArray[i+temp[k][0]][j+temp[k][1]] == 0 )
                        {
                            //表示有一格是空白
                            empty++ ;
                        }
                        if( k == 4 && empty > 0  )
                        {
                            return 1 ;
                        }
                    }
                    else
                    {
                        break ;
                    }
                }
            }
        }
        return 0 ;
    }

    public void showTextView(CharSequence mT){
        this.mStatusTextView.setText(mT);
        mStatusTextView.setVisibility(View.VISIBLE);

    }

    public void init_maps()
    {
        DoubleManHard parent = (DoubleManHard)getContext();
        maps2 M = new maps2() ;

        //int index =(int)(Math.random()*13);
        //int index =chooseLevel;
        int index= Integer.valueOf(parent.name);//第幾關

        int map [] = new int [M.map[index].length];

        M.get_maps(map,index);

        for(int i = 0 ; i <= map.length-1 ; i++ )
        {
            mGridArray[map[i]%GRID_SIZE][map[i]/GRID_SIZE] = 7 ;//13一進位
        }
        this.invalidate();
        Toast toast = Toast.makeText(parent, index + " ", Toast.LENGTH_SHORT);
        toast.show();
    }
    public void finish_score(){
   	 
    	for( int i = 0 ; i < GRID_SIZE -1 ; i++ )
        {
            for( int j = 0 ; j < GRID_SIZE-1 ; j++ )
            {
               if(mGridArray[i][j]==1)
            	   player1Score++;
               else if(mGridArray[i][j]==2)
            	   player2Score++;
            }
        }
    }
}
