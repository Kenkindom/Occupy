package com.example.jason.occupy;


import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.Toast;


public class LevelNormal extends Fragment {

		private View v;
		private GridView gridView;
		private int[] image = {
				 R.drawable.orangeafter1, R.drawable.orangeafter2,
		            R.drawable.orangeafter3, R.drawable.orangeafter4,
		            R.drawable.orangeafter5, R.drawable.orangeafter6,
		            R.drawable.orangeafter7, R.drawable.orangeafter8,
		            R.drawable.orangeafter9, R.drawable.orangeafter10,
		            R.drawable.orangeafter11, R.drawable.orangeafter12,
		            R.drawable.orangeafter13, R.drawable.orangeafter14,
		            R.drawable.orangeafter15,/* R.drawable.orange16,
		            R.drawable.orange17, R.drawable.orange18,
		            R.drawable.orange19, R.drawable.orange20,
		            R.drawable.orange21, R.drawable.orange22,
		            R.drawable.orange23, R.drawable.orange24,
		            R.drawable.orange25, R.drawable.orange26,
		            R.drawable.orange27, R.drawable.orange28,
		            R.drawable.orange29, R.drawable.orange30*/
	    };
		@Override
		public void onAttach(Activity activity) {
			super.onAttach(activity);
			
			//BeforeLevel mainActivity = (BeforeLevel)activity;
			//value = mainActivity.getAppleData();
		}
		private String[] imgText = {
	            "1", "2", "3", "4", "5", "6", "7", "8","9","10","11","12","13","14",
	            "15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30"
	    };
		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			
			 v=inflater.inflate(R.layout.level_normal, container, false);
			 GridView gridview = (GridView) v.findViewById(R.id.gridViewLevelNormal);
			 gridview.setAdapter(new ImageAdapterLevelNormal(getActivity()));
			 gridview.setOnItemClickListener(new OnItemClickListener() {
		            public void onItemClick(AdapterView<?> parent, View v,
		                    int position, long id) {
		               
		                Intent it= new Intent();
		                if(position==0)
		                {	//background.setBackgroundColor(Color.GREEN);
		                	
							it.setClass(getActivity(),linear.class);
							it.putExtra("leve","12");
							it.putExtra("widt","10");
							startActivity(it);
							getActivity().finish();
		                }else if(position==1)
		                {	
							it.setClass(getActivity(),linear.class);
							it.putExtra("leve","13");
							it.putExtra("widt", "10");
							startActivity(it);
							getActivity().finish();
		                }else if(position==2)
		                {	//background.setBackgroundColor(Color.BLUE);
		                	it.setClass(getActivity(),linear.class);
							it.putExtra("leve","14");
							it.putExtra("widt","10");
							startActivity(it);
							getActivity().finish();
		                }else if(position==3)
		                {	
							it.setClass(getActivity(),linear.class);
							it.putExtra("leve","15");
							it.putExtra("widt","10");
							startActivity(it);
							getActivity().finish();
		                }else if(position==4)
		                {	
							it.setClass(getActivity(),linear.class);
							it.putExtra("leve","16");
							it.putExtra("widt","10");
							startActivity(it);
							getActivity().finish();
		                }else if(position==5)
		                {	
							it.setClass(getActivity(),linear.class);
							it.putExtra("leve","17");
							it.putExtra("widt", "10");
							startActivity(it);
							getActivity().finish();
		                }else if(position==6)
		                {	
							it.setClass(getActivity(),linear.class);
							it.putExtra("leve","18");
							it.putExtra("widt", "10");
							startActivity(it);
							getActivity().finish();
		                }else if(position==7)
		                {	
							it.setClass(getActivity(),linear.class);
							it.putExtra("leve","19");
							it.putExtra("widt", "10");
							startActivity(it);
							getActivity().finish();
		                }else if(position==8)
		                {	
							it.setClass(getActivity(),linear.class);
							it.putExtra("leve","20");
							it.putExtra("widt", "10");
							startActivity(it);
							getActivity().finish();
		                }else if(position==9)//level 10
		                {	
							it.setClass(getActivity(),linear.class);
							it.putExtra("leve","21");
							it.putExtra("widt", "10");
							startActivity(it);
							getActivity().finish();
		                }else if(position==10)//level 11
		                {	
							it.setClass(getActivity(),linear.class);
							it.putExtra("leve","22");
							it.putExtra("widt", "10");
							startActivity(it);
							getActivity().finish();
		                }else if(position==11)//level 12
		                {	
							it.setClass(getActivity(),linear.class);
							it.putExtra("leve","23");
							it.putExtra("widt", "10");
							startActivity(it);
							getActivity().finish();
		                }
		            }
		        });
			 return v;
		}
		
		@Override
		public void onActivityCreated(Bundle savedInstanceState) {
			super.onActivityCreated(savedInstanceState);
			Log.d("=====>", "AppleFragment onActivityCreated");
			// GridView gridview = (GridView) this.getView().findViewById(R.id.gridViewLevel);
		     //   gridview.setAdapter(new ImageAdapterLevel(this));
		       
			//TextView txtResult = (TextView) this.getView().findViewById(R.id.textView1);
			//txtResult.setText(value);
		}
   /* @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        //getMenuInflater().inflate(R.menu.main, menu);
        
        return super.onCreateOptionsMenu(menu);
    }*/

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
