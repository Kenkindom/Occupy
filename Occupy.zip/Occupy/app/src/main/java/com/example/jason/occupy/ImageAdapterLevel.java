package com.example.jason.occupy;

import android.app.Activity;
import android.content.Context;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;

public class ImageAdapterLevel extends BaseAdapter {
    private Context mContext;
    
    public ImageAdapterLevel(Context c) {
        mContext = c;
    }

    public ImageAdapterLevel(Apple apple) {
		// TODO Auto-generated constructor stub
	}

	public int getCount() {
        return mThumbIds.length;
    }

    public Object getItem(int position) {
        return null;
    }

    public long getItemId(int position) {
        return 0;
    }

    // create a new ImageView for each item referenced by the Adapter
    public View getView(int position, View convertView, ViewGroup parent) {
        ImageView imageView;
       
        if (convertView == null) {
            // if it's not recycled, initialize some attributes
            imageView = new ImageView(mContext);
            imageView.setLayoutParams(new GridView.LayoutParams(250, 250));
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            imageView.setPadding(8, 8, 8, 8);
        } else {
            imageView = (ImageView) convertView;
        }

        imageView.setImageResource(mThumbIds[position]);
        return imageView;
    }

    // references to our images
    private Integer[] mThumbIds = {
            R.drawable.orangeafter1, R.drawable.orangeafter2,
            R.drawable.orangeafter3, R.drawable.orangeafter4,
            R.drawable.orangeafter5, R.drawable.orangeafter6,
            R.drawable.orangeafter7, R.drawable.orangeafter8,
            R.drawable.orangeafter9, R.drawable.orangeafter10,
            R.drawable.orangeafter11, R.drawable.orangeafter12,
            R.drawable.orangeafter13, R.drawable.orangeafter14,
            R.drawable.orangeafter15,  /*R.drawable.orange16,
           R.drawable.orange17, R.drawable.orange18,
            R.drawable.orange19, R.drawable.orange20,
            R.drawable.orange21, R.drawable.orange22,
            R.drawable.orange23, R.drawable.orange24,
            R.drawable.orange25, R.drawable.orange26,
            R.drawable.orange27, R.drawable.orange28,
            R.drawable.orange29, R.drawable.orange30*/
            
    };
}