package com.example.jason.occupy;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

public class Apple extends Fragment {
	
	private String value = "";
	private View v;
	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		Log.d("=====>", "AppleFragment onAttach");
		BeforeLevel mainActivity = (BeforeLevel)activity;
		value = mainActivity.getAppleData();
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		Log.d("=====>", "AppleFragment onCreateView");
		v=inflater.inflate(R.layout.level_choose2, container, false);
		 GridView gridview = (GridView) v.findViewById(R.id.gridViewLevel2);
		 gridview.setAdapter(new ImageAdapterLevel2(getActivity()));
		 gridview.setOnItemClickListener(new OnItemClickListener() {
	            public void onItemClick(AdapterView<?> parent, View v,
	                    int position, long id) {
	               
	                Intent it= new Intent();
	                if(position==0)
	                {	//background.setBackgroundColor(Color.GREEN);
	                	
						it.setClass(getActivity(),DoubleManHard.class);
						it.putExtra("leve","0");
						it.putExtra("widt","10");
						startActivity(it);
						getActivity().finish();
	                }
	            }
	        });
		 return v;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		Log.d("=====>", "AppleFragment onActivityCreated");
		// GridView gridview = (GridView) this.getView().findViewById(R.id.gridViewLevel);
	     //   gridview.setAdapter(new ImageAdapterLevel(this));
	       
		//TextView txtResult = (TextView) this.getView().findViewById(R.id.textView1);
		//txtResult.setText(value);
	}
}
