package com.example.jason.occupy;

import android.app.Activity;
import android.content.Context;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;

public class ImageAdapterLevel2 extends BaseAdapter {
    private Context mContext;
    
    public ImageAdapterLevel2(Context c) {
        mContext = c;
    }

    public int getCount() {
        return mThumbIds.length;
    }

    public Object getItem(int position) {
        return null;
    }

    public long getItemId(int position) {
        return 0;
    }

    // create a new ImageView for each item referenced by the Adapter
    public View getView(int position, View convertView, ViewGroup parent) {
        ImageView imageView;
       
        if (convertView == null) {
            // if it's not recycled, initialize some attributes
            imageView = new ImageView(mContext);
            imageView.setLayoutParams(new GridView.LayoutParams(250, 250));
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            imageView.setPadding(8, 8, 8, 8);
        } else {
            imageView = (ImageView) convertView;
        }

        imageView.setImageResource(mThumbIds[position]);
        return imageView;
    }

    // references to our images
    private Integer[] mThumbIds = {
            R.drawable.orangeafter16,
           R.drawable.orangeafter17, R.drawable.orangeafter18,
            R.drawable.orangeafter19, R.drawable.orangeafter20,
            R.drawable.orangeafter21, R.drawable.orangeafter22,
            R.drawable.orangeafter23, R.drawable.orangeafter24,
            R.drawable.orangeafter25, R.drawable.orangeafter26,
            R.drawable.orangeafter27, R.drawable.orangeafter28,
            R.drawable.orangeafter29, R.drawable.orangeafter30
            
    };
}