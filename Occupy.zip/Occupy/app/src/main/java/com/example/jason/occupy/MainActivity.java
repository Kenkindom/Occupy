package com.example.jason.occupy;


import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.widget.Button;


public class MainActivity extends Activity {

		private Button single,bluetooth,sinVS;
		final String[] arrayFruit = new String[] { "同機雙打", "電腦對戰", "連線對戰" };
	       
		protected void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        //requestWindowFeature(Window.FEATURE_NO_TITLE);//去除標題列
	        setContentView(R.layout.activity_main);
	        
	         single = (Button) findViewById(R.id.single);
			bluetooth = (Button) findViewById(R.id.bluetooth);
			sinVS = (Button) findViewById(R.id.sinVSsin);
			
			single.setOnTouchListener(new OnTouchListener() {
			    @Override
			    public boolean onTouch(View v, MotionEvent event) {
			        if(event.getAction() == MotionEvent.ACTION_DOWN) {
			        	single.setBackgroundResource(R.drawable.buttonshape);
			        } else if (event.getAction() == MotionEvent.ACTION_UP) {
			        	Intent it= new Intent();
					it.setClass(MainActivity.this,BeforeAiLevel.class);
					startActivity(it);
					single.setBackgroundResource(R.drawable.buttonshape3);
					MainActivity.this.finish();
			        }
			        return false;
			    }
			    
			});
			bluetooth.setOnTouchListener(new OnTouchListener() {
			    @Override
			    public boolean onTouch(View v, MotionEvent event) {
			        if(event.getAction() == MotionEvent.ACTION_DOWN) {
			        	bluetooth.setBackgroundResource(R.drawable.buttonshape);
			        } else if (event.getAction() == MotionEvent.ACTION_UP) {
			        	Intent it= new Intent();
					it.setClass(MainActivity.this,BlueOnlineBefore.class);
					startActivity(it);
					bluetooth.setBackgroundResource(R.drawable.buttonshape3);
					MainActivity.this.finish();
			        }
			        return false;
			    }
			    
			});
			sinVS.setOnTouchListener(new OnTouchListener() {
			    @Override
			    public boolean onTouch(View v, MotionEvent event) {
			        if(event.getAction() == MotionEvent.ACTION_DOWN) {
			        	sinVS.setBackgroundResource(R.drawable.buttonshape);
			        } else if (event.getAction() == MotionEvent.ACTION_UP) {
			        	Intent it= new Intent();
					it.setClass(MainActivity.this,BeforeLevel.class);
					startActivity(it);
					sinVS.setBackgroundResource(R.drawable.buttonshape3);
					 MainActivity.this.finish();
			        }
			        return false;
			    }
			    
			});
		}
		@Override
		public boolean onKeyDown(int keyCode, KeyEvent event) {//捕捉返回鍵
	        if ((keyCode == KeyEvent.KEYCODE_BACK)) {
	        	//Intent it= new Intent();
				//it.setClass(MainActivity.this,Start.class);
				//startActivity(it);
				MainActivity.this.finish();
	            return true;   
	        }   
	        return super.onKeyDown(keyCode, event);   
	    }
    public void test(){
    	Dialog alertDialog = new AlertDialog.Builder(this).
                setTitle("選擇模式").  
                  
                setItems(arrayFruit, new DialogInterface.OnClickListener() {
   
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //Toast.makeText(Dialog_AlertDialogDemoActivity.this, arrayFruit[which], Toast.LENGTH_SHORT).show();  
                    	if(which==1)
                    	{Intent it= new Intent();
    					it.setClass(MainActivity.this,linear.class);
    					startActivity(it);
                    	}
                    }  
                }).  
                setNegativeButton("取消", new DialogInterface.OnClickListener() {
  
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    	dialog.dismiss();
                    }  
                }).  
                create();
    	alertDialog.show(); 
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        //getMenuInflater().inflate(R.menu.main, menu);
        //menu.add(1,1,1,"同機雙打");
        //menu.add(1,2,2,"連線對戰");
        //menu.add(1,3,3,"電腦對戰");
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
