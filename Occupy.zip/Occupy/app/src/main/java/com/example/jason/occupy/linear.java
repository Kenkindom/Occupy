package com.example.jason.occupy;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Context;
import android.util.AttributeSet;

public class linear extends Activity {
	

	Test_view t,t2,TEST;  //�s�WTEST��Test_viewc class���A
	Test_view2 s;
	Test_viewAi s_ai;
	Button b;
	int index;
	int testindex;


	public static int index_ai;
	int turn = 1 ,ans=1,conquer_other=0,start=0;//佔到別人的
	public String name_level;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.square);
//---------------------------------------------------------------------------------------------------------------------------------------

		 Intent intent = this.getIntent();//取得哪個關卡資訊
	       name_level = intent.getStringExtra("leve");
        shape temp_shape = new shape() ;
		shape test1 = new shape() ;
		shape ai_shape = new shape() ;

		//產生玩家第一個方塊
		index = temp_shape.got_index();

		//產生玩家第2個方塊
		testindex = test1.got_index();

        //產生電腦第一個方塊
		index_ai=ai_shape.got_index();


//---------------------------------------------------------------------------------------------------------------------------------------
		
		t = (Test_view)this.findViewById(R.id.view1);
		TEST = (Test_view)this.findViewById(R.id.view1);
		s = (Test_view2)this.findViewById(R.id.view2);
		s_ai = (Test_viewAi)this.findViewById(R.id.view3);
		if(Integer.parseInt(name_level)>=0&& Integer.parseInt(name_level)<=11)
			t.ai_level=1;
		else if(Integer.parseInt(name_level)>=12&& Integer.parseInt(name_level)<=23)
			t.ai_level=2;
		else if(Integer.parseInt(name_level)>=24)
			t.ai_level=3;
		
		
		if(Integer.parseInt(name_level)!=0&& Integer.parseInt(name_level)!=12&& Integer.parseInt(name_level)!=24
				&& Integer.parseInt(name_level)!=33&& Integer.parseInt(name_level)!=34) //第1關沒有黑格子 其它關要跑init_maps
		       t.init_maps();
		if(Integer.parseInt(name_level)==33|| Integer.parseInt(name_level)==34)
			t.spec_maps();
		b=(Button)findViewById(R.id.choose);

		 b.setOnClickListener(new Button.OnClickListener(){
	         @Override
	         public void onClick(View v) {
				 


	     		t = (Test_view)findViewById(R.id.view1);
	    		s = (Test_view2)findViewById(R.id.view2);
	    		s_ai=(Test_viewAi)findViewById(R.id.view3);
	    		if(conquer_other==1&&t.ifending!=1)
	    		{Toast toast = Toast.makeText(linear.this, "can't conquer", Toast.LENGTH_SHORT);
	             toast.show();

	    			return;
	    		}
	    		if(t.blank>0)//玩家有下
	    		{
	    		index = testindex;
				 shape test2 = new shape() ;
				 testindex = test2.got_index();
	    		ans=0;


	    		t.change_line(t.x, t.y, t.shape, turn);

				 turn = 1;
				 t.blank=0;//歸0
	    		}
				 t.invalidate();

	    		s.postInvalidate();
	    		s_ai.postInvalidate();


	         }

	     });

	}
	 @Override
	    public void onDestroy() {
	        super.onDestroy();
	        t.bitmap.recycle();
	        t.bitmap2.recycle();
	        t.bitmaptest.recycle();
	        t.bitmaptest2.recycle();
	        System.gc();
	       
	    }
	public int getImportantInt() { return index; }
	public int getImportantAi(){return index_ai;}
	public int getturn(){ return turn ; }
	public int getstart(){return start;}
	public int getAnswer(){
		if(ans==0){++ans;return 0;}
		else{return 1;}
	}
	public void ending(){
   	 AlertDialog.Builder ad=new AlertDialog.Builder(linear.this);
   	 	//if(t.play)
	        ad.setTitle("score:"+t.playerScore+" to "+t.aiScore);
	        ad.setMessage("Do you want to play again?");
	        ad.setPositiveButton("Yes", new DialogInterface.OnClickListener() {//退出按鈕
	            public void onClick(DialogInterface dialog, int i) {
	                // TODO Auto-generated method stub
	            	
	            	Intent it= new Intent();
	            	it.setClass(linear.this,BeforeAiLevel.class);
	            	startActivity(it);
	            	linear.this.finish();//關閉activity
	            }
	        });
	        ad.setNegativeButton("No",new DialogInterface.OnClickListener() {
	            public void onClick(DialogInterface dialog, int i) {
	            	/*Intent it= new Intent();
	            	it.setClass(linear.this,Start.class);
	            	startActivity(it);*/
	            	linear.this.finish();//關閉activity
	          	  
	            }
	        });
	        ad.show();//示對話框
   }
}