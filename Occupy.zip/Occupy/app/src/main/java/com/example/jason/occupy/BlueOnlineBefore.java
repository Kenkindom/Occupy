package com.example.jason.occupy;


import java.util.Timer;
import java.util.TimerTask;

import com.example.*;
import android.support.v7.app.ActionBarActivity;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


public class BlueOnlineBefore extends Activity {
	private boolean change = false;
	private BluetoothAdapter mBluetoothAdapter = null;
	private static final int REQUEST_ENABLE_BT = 3;
    private TextView touchChange;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);//去除標題列
        setContentView(R.layout.bluetooth_before);

        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        //如果mBluetoothAdapter為null 說明目前手機沒有藍芽模組
        // If the adapter is null, then Bluetooth is not supported
        if (mBluetoothAdapter == null) {
            Toast.makeText(this, "Bluetooth is not available", Toast.LENGTH_LONG).show();
            finish();
            return;
        }


        final TextView test = (TextView) findViewById(R.id.text_entergame);//請點擊進入遊戲
		Timer timer = new Timer();
		TimerTask task = new TimerTask() {
			public void run() {
				runOnUiThread(new Runnable() {
					public void run() {
						if (change) {
							change = false;
							test.setTextColor(Color.TRANSPARENT); // 讓文字透明
						} else {
							change = true;
							test.setTextColor(Color.DKGRAY);
						}
					}
				});
			}
		};
		timer.schedule(task, 1, 800); // 參數分別是(timer需要做什麼事情，執行後多久開始執行，閃爍速度多快)

		touchChange = (TextView)findViewById(R.id.winner);
		touchChange.setOnClickListener(new OnClickListener() {
		@Override
		public void onClick(View v) {
			gotoMain();
		}
	});
   }

    @Override
    public void onStart() {
        super.onStart();

        // If BT is not on, request that it be enabled.
        // setupChat() will then be called during onActivityResult
        if (!mBluetoothAdapter.isEnabled()) {
            Intent enableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableIntent, REQUEST_ENABLE_BT);

        // Otherwise, setup the chat session
        }
    }
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
         switch (requestCode) {

        case REQUEST_ENABLE_BT:
            // When the request to enable Bluetooth returns
            if (resultCode == Activity.RESULT_OK) {
                // Bluetooth is now enabled, so set up a chat session
               // setupChat();
            } else {
                // User did not enable Bluetooth or an error occurred

                Toast.makeText(this, R.string.bt_not_enabled_leaving, Toast.LENGTH_SHORT).show();
                finish();
            }
        }
    }
private void gotoMain(){
	Intent intent = new Intent(this, BlueOnline.class);
	startActivity(intent);
	finish();
}
@Override
public boolean onKeyDown(int keyCode, KeyEvent event) {//捕捉返回鍵
    if ((keyCode == KeyEvent.KEYCODE_BACK)) {
    	//Intent it= new Intent();
		//it.setClass(MainActivity.this,Start.class);
		//startActivity(it);
		BlueOnlineBefore.this.finish();
        return true;   
    }   
    return super.onKeyDown(keyCode, event);   
}
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
