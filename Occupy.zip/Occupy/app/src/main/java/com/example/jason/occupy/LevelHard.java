package com.example.jason.occupy;


import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.Toast;


public class LevelHard extends Fragment {

		private View v;
		private GridView gridView;
		private int[] image = {
				 R.drawable.orangeafter31, R.drawable.orangeafter32,
		            R.drawable.orangeafter33, R.drawable.orangeafter34,
		            R.drawable.orangeafter35, R.drawable.orangeafter36,
		            R.drawable.orangeafter37, R.drawable.orangeafter38,
		            R.drawable.orangeafter39, R.drawable.orangeafter40,
		            R.drawable.orangeafter41, R.drawable.orangeafter42,
		            R.drawable.orangeafter43, R.drawable.orangeafter44,
		            R.drawable.orangeafter45,/* R.drawable.orange16,
		            R.drawable.orange17, R.drawable.orange18,
		            R.drawable.orange19, R.drawable.orange20,
		            R.drawable.orange21, R.drawable.orange22,
		            R.drawable.orange23, R.drawable.orange24,
		            R.drawable.orange25, R.drawable.orange26,
		            R.drawable.orange27, R.drawable.orange28,
		            R.drawable.orange29, R.drawable.orange30*/
	    };
		@Override
		public void onAttach(Activity activity) {
			super.onAttach(activity);
			
			//BeforeLevel mainActivity = (BeforeLevel)activity;
			//value = mainActivity.getAppleData();
		}
		private String[] imgText = {
	            "1", "2", "3", "4", "5", "6", "7", "8","9","10","11","12","13","14",
	            "15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30"
	    };
		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			
			 v=inflater.inflate(R.layout.level_hard, container, false);
			 GridView gridview = (GridView) v.findViewById(R.id.gridViewLevelHard);
			 gridview.setAdapter(new ImageAdapterLevelHard(getActivity()));
			 gridview.setOnItemClickListener(new OnItemClickListener() {
		            public void onItemClick(AdapterView<?> parent, View v,
		                    int position, long id) {
		               
		                Intent it= new Intent();
		                if(position==0)//24-35
		                {	//background.setBackgroundColor(Color.GREEN);
		                	
							it.setClass(getActivity(),linear.class);
							it.putExtra("leve","24");
							it.putExtra("widt","10");
							startActivity(it);
							getActivity().finish();
		                }else if(position==1)
		                {	
							it.setClass(getActivity(),linear.class);
							it.putExtra("leve","25");
							it.putExtra("widt", "10");
							startActivity(it);
							getActivity().finish();
		                }else if(position==2)
		                {	//background.setBackgroundColor(Color.BLUE);
		                	it.setClass(getActivity(),linear.class);
							it.putExtra("leve","26");
							it.putExtra("widt","10");
							startActivity(it);
							getActivity().finish();
		                }else if(position==3)
		                {	
							it.setClass(getActivity(),linear.class);
							it.putExtra("leve","27");
							it.putExtra("widt","10");
							startActivity(it);
							getActivity().finish();
		                }else if(position==4)
		                {	
							it.setClass(getActivity(),linear.class);
							it.putExtra("leve","28");
							it.putExtra("widt","10");
							startActivity(it);
							getActivity().finish();
		                }else if(position==5)
		                {	
							it.setClass(getActivity(),linear.class);
							it.putExtra("leve","29");
							it.putExtra("widt", "10");
							startActivity(it);
							getActivity().finish();
		                }else if(position==6)
		                {	
							it.setClass(getActivity(),linear.class);
							it.putExtra("leve","30");
							it.putExtra("widt", "10");
							startActivity(it);
							getActivity().finish();
		                }else if(position==7)
		                {	
							it.setClass(getActivity(),linear.class);
							it.putExtra("leve","31");
							it.putExtra("widt", "10");
							startActivity(it);
							getActivity().finish();
		                }else if(position==8)
		                {	
							it.setClass(getActivity(),linear.class);
							it.putExtra("leve","32");
							it.putExtra("widt", "10");
							startActivity(it);
							getActivity().finish();
		                }else if(position==9)
		                {	
							it.setClass(getActivity(),linear.class);
							it.putExtra("leve","33");
							it.putExtra("widt", "10");
							startActivity(it);
							getActivity().finish();
		                }else if(position==10)
		                {	
							it.setClass(getActivity(),linear.class);
							it.putExtra("leve","34");
							it.putExtra("widt", "10");
							startActivity(it);
							getActivity().finish();
		                }else if(position==11)
		                {	
							it.setClass(getActivity(),linear.class);
							it.putExtra("leve","35");
							it.putExtra("widt", "10");
							startActivity(it);
							getActivity().finish();
		                }
		            }
		        });
			 return v;
		}
		
		@Override
		public void onActivityCreated(Bundle savedInstanceState) {
			super.onActivityCreated(savedInstanceState);
			Log.d("=====>", "AppleFragment onActivityCreated");
			// GridView gridview = (GridView) this.getView().findViewById(R.id.gridViewLevel);
		     //   gridview.setAdapter(new ImageAdapterLevel(this));
		       
			//TextView txtResult = (TextView) this.getView().findViewById(R.id.textView1);
			//txtResult.setText(value);
		}
   /* @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        //getMenuInflater().inflate(R.menu.main, menu);
        
        return super.onCreateOptionsMenu(menu);
    }*/

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
