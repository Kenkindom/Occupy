package com.example.jason.occupy;


import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTabHost;
import android.support.v7.app.ActionBarActivity;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.Toast;


public class BeforeLevel extends FragmentActivity {

		private Button easylevel,hardlevel;
		
		protected void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        //requestWindowFeature(Window.FEATURE_NO_TITLE);//去除標題列
	        setContentView(R.layout.before_level_choose);
	        //獲取TabHost控制元件
	        FragmentTabHost tabHost = (FragmentTabHost)findViewById(android.R.id.tabhost);

	        //設定Tab頁面的顯示區域，帶入Context、FragmentManager、Container ID
	        tabHost.setup(this, getSupportFragmentManager(), R.id.realtabcontent);

			//1
			tabHost.addTab(tabHost.newTabSpec("Easy")
				   				  .setIndicator("Easy"), //看setIndicator
				   				 Level.class,
	   					  null);
			tabHost.addTab(tabHost.newTabSpec("Hard")
	   				  .setIndicator("Hard"), //看setIndicator
				  Level2.class,
				  null);
			/*
	        easylevel = (Button) findViewById(R.id.easy_level);
	        hardlevel = (Button) findViewById(R.id.hard_level);


			easylevel.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					Intent it= new Intent();
					it.setClass(BeforeLevel.this,Level.class);
					startActivity(it);
					BeforeLevel.this.finish();//關閉activity

				}
			});
			hardlevel.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					Intent it= new Intent();
					it.setClass(BeforeLevel.this,Level2.class);
					startActivity(it);
					BeforeLevel.this.finish();//關閉activity

				}
			}); */
		}
		@Override
		public boolean onKeyDown(int keyCode, KeyEvent event) {//捕捉返回鍵
	        if ((keyCode == KeyEvent.KEYCODE_BACK)) {
	        	
				BeforeLevel.this.finish();
	            return true;   
	        }   
	        return super.onKeyDown(keyCode, event);   
	    }	
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        //getMenuInflater().inflate(R.menu.main, menu);
        
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    public String getAppleData(){
		return "what the";
	}
}
