package com.example.jason.occupy;




import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Shader;
import android.graphics.Shader.TileMode;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;


public class Blue_view1 extends View {
	protected static int GRID_SIZE = 10;
    protected int GRID_WIDTH =30;
    protected static int CHESS_DIAMETER = 26; // 棋的直径
    protected static int mStartX;// 棋盘定位的左上角X
    protected static int mStartY;// 棋盘定位的左上角Y

    private Bitmap[] mChessBW; // 黑棋和白棋
    public static int[][] mGridArray; // 网格
    private static int[][] staticArray;
    public static int[][] thirdArray;
    private static int[] row;
    private static int[] col;
    
    boolean key = false;
    
    Blue_view2 s;
    
    int shape[][] = new int[5][2];//目前圖形
    int turn = 0 ;
    public static int wbflag = 1; //该下白棋了=2，该下黑棋了=1. 这里先下黑棋（黑棋以后设置为机器自动下的棋子）
    int mLevel = 1; //游戏难度
    int mWinFlag = 0;
    int makeup=1;//按的次數
    int now_up=makeup;
    int x;
    int y;
    int if_conquer=0,if_release=0;
    String convey="";
    private final int BLACK=1;
    private final int WHITE=2;
    
    int mGameState = GAMESTATE_RUN; //游戏阶段：0=尚未游戏，1=正在进行游戏，2=游戏结束
    static final int GAMESTATE_PRE = 0;
    static final int GAMESTATE_RUN = 1;
    static final int GAMESTATE_PAUSE = 2;
    static final int GAMESTATE_END = 3;

    //private TextView mStatusTextView; //  根据游戏状态设置显示的文字
    public TextView mStatusTextView; //  根据游戏状态设置显示的文字
    //public TextView order;
    private Bitmap btm1;
    private final Paint mPaint = new Paint();
   
    CharSequence mText;
    CharSequence STRING_WIN = "White win! /n Press Fire Key to start new game.";
    CharSequence STRING_LOSE = "Black win! /n Press Fire Key to start new game.";
    CharSequence STRING_EQUAL = "Cool! You are equal! /n Press Fire Key to start new Game.";
    public int compare_who_one=1;//和blueOnline比較一不一樣
    public Blue_view1(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init();
      }

    public Blue_view1(Context context, AttributeSet attrs) { //好像调用的是这个构造函数，为什么不是前面的呢
        super(context, attrs);
        this.setFocusable(true);  //20090530
        this.setFocusableInTouchMode(true);
       // order=(TextView)findViewById(R.id.set);
        //GRID_WIDTH=metrics.widthPixels; // 棋盘格的宽度
        init();
    }

  
    //这里画棋子后来没有用图片画，而是直接画了圆。因为我做的图片不好看。
    // 初始化黑白棋的Bitmap
    public void init() {
        mGameState = 1; //设置游戏为开始状态
        wbflag = BLACK; //初始为先下黑棋
        mWinFlag = 0; //清空输赢标志。
        mGridArray = new int[GRID_SIZE-1][GRID_SIZE-1];
        staticArray = new int[GRID_SIZE-1][GRID_SIZE-1];
        thirdArray=new int[GRID_SIZE-1][GRID_SIZE-1];
        row = new int [GRID_SIZE-1];
        col = new int [GRID_SIZE-1];
        
        turn = 1 ;
        for(int i=0;i<GRID_SIZE-1;i++)
        {
        	for(int j=0;j<GRID_SIZE-1;j++)
        	{
        		staticArray[i][j]=0;
        		thirdArray[i][j]=0;
        	}
        	row[i] = 0 ;
        	col[i] = 0 ;
        }
        
        mChessBW = new Bitmap[2];
        s = (Blue_view2)this.findViewById(R.id.bview2);//不確定要不要
        Bitmap bitmap = Bitmap.createBitmap(CHESS_DIAMETER, CHESS_DIAMETER, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        Resources r = this.getContext().getResources();

        
  }

    
    public void setTextView(TextView tv){
        mStatusTextView =tv;
        mStatusTextView.setVisibility(View.INVISIBLE);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        mStartX = w/GRID_SIZE;
        mStartY =  h/GRID_SIZE;
    	GRID_WIDTH=w/11;
        super.onSizeChanged(w, h, oldw, oldh);  
    }
    
    public void check_bound(int temp[][],int x,int y)
    {
    	int up=0,down=0,left=0,right=0,just_x=0,just_y=0;
    	
    	for(int i = 0 ; i < 5 ; i++ )
    	{
    		if(x+temp[i][0] < 0)
    		{
    			up = 1 ;
    			just_x = 1 ;
    			break ;
    		}
    		else if(x+temp[i][0] >= GRID_SIZE-1)
    		{
    			down = 1 ; 
    			just_x = -1 ;
    			break ;
    		}
    		else if(y+temp[i][1] < 0)
    		{
    			left = 1 ;
    			just_y = 1 ;
    			break ;
    		}
    		else if(y+temp[i][1] >= GRID_SIZE-1)
    		{
    			right = 1 ;
    			just_y = -1 ;
    			break ;
    		}
    	}
    	
    	if( up==1 || down==1 || left==1 || right==1 )
    	{
    		for(int i = 0;i < 5;i++)
    		{
    			temp[i][0] += just_x ;
    			temp[i][1] += just_y ;
    		}
    		check_bound(temp,x,y) ;
    	}
    	else
    	{
    		return ;
    	}
    }
    
     @Override
    public boolean onTouchEvent(MotionEvent event){
    	 BlueOnline parent = (BlueOnline)getContext(); // I meant this line
         
    	 wbflag = parent.getChange();//change_who
    	 if(BlueOnline.turn==wbflag&&BlueOnline.sure_who_first!=0){
         	
         
    	 switch (mGameState) {
        case GAMESTATE_PRE:
            break;
        case GAMESTATE_RUN: {
                
                float x1=event.getX();
                float y1=event.getY();
                float x0 = GRID_WIDTH - (event.getX() - mStartX) % GRID_WIDTH;
                float y0 = GRID_WIDTH - (event.getY() - mStartY) % GRID_WIDTH;
                x = (int) ((event.getX() - mStartX) / GRID_WIDTH) ;//點的X位子
                y = (int) ((event.getY() - mStartY) / GRID_WIDTH) ;
                shape temp_shape = new shape() ;
                 convey="";
                int index = parent.getImportantInt();
                
                convey+=""+wbflag;
               // Toast toast2 = Toast.makeText( parent, "x:"+x+"y:"+y, Toast.LENGTH_SHORT);
	            // toast2.show();
                switch(event.getAction())
                {
                case MotionEvent.ACTION_DOWN:
                	now_up=makeup;
        			temp_shape.getShape_XY(index, shape);
        			check_bound(shape,x,y);//不確定要不要改 左邊會一直縮近來?
                	mText="index: "+ String.format("%d\n", index)+
                			"tempx1: "+ String.format("%d", thirdArray[0][0])+
    	            		"tempy1: "+ String.format("%d\n", thirdArray[0][1])+
    	            		"tempx2: "+ String.format("%d", thirdArray[0][2])+
    	            		"tempy2: "+ String.format("%d\n", thirdArray[0][3])+
	            		"tempx3: "+ String.format("%d", shape[2][0])+
	            		"tempy3: "+ String.format("%d\n", shape[2][1])+
	            		"tempx4: "+ String.format("%d", shape[3][0])+
	            		"tempy4: "+ String.format("%d\n", shape[3][1])+
	            		"tempx5: "+ String.format("%d", shape[4][0])+
	            		"tempy5: "+ String.format("%d\n", shape[4][1])+
	            		"X: "+ String.format("%d\n", x)+
	            		"Y: " + String.format("%d", y);
                	//showTextView(mText);
                	for(int i = 0 ; i < GRID_SIZE-1 ; i++ )//GRID_SIZE=10
                	{
                		for(int j = 0 ; j < GRID_SIZE-1 ; j++ )
                		{
                			staticArray[i][j] = mGridArray[i][j];//存進去
                		}
                	}
                	//x 1 or 0?
                	if ((x >= 0 && x < GRID_SIZE - 1) && (y >= 0 && y < GRID_SIZE - 1)) 
                    {
                		if (mGridArray[x][y] == 0||mGridArray[x][y] == 1||mGridArray[x][y] == 2) 
                        {
                            if (wbflag == BLACK) 
                            {
                               for( int i = 0 ; i < 5 ; i++)
                                {
                                	putChess2(x+shape[i][0], y+shape[i][1], BLACK);
                                }
                            } 
                            else if (wbflag == WHITE) 
                            {
                                for( int i = 0 ; i < 5 ; i++)
                                {
                                	putChess2(x+shape[i][0], y+shape[i][1], WHITE);
                                }
                            }
                        }
                		
                    }
                	
                	break;
                case MotionEvent.ACTION_UP:
                	makeup++;
                	
                	mText="index: "+ String.format("%d\n", index)+
	            		"tempx1: "+ String.format("%d", thirdArray[0][0])+
	            		"tempy1: "+ String.format("%d\n", thirdArray[0][1])+
	            		"tempx2: "+ String.format("%d", thirdArray[0][2])+
	            		"tempy2: "+ String.format("%d\n", thirdArray[0][3])+
	            		"tempx3: "+ String.format("%d", shape[2][0])+
	            		"tempy3: "+ String.format("%d\n", shape[2][1])+
	            		"tempx4: "+ String.format("%d", shape[3][0])+
	            		"tempy4: "+ String.format("%d\n", shape[3][1])+
	            		"tempx5: "+ String.format("%d", shape[4][0])+
	            		"tempy5: "+ String.format("%d\n", shape[4][1])+
	            		"X: "+ String.format("%d\n", x)+
	            		"Y: " + String.format("%d", y);
                	//showTextView(mText);
                	for(int i = 0 ; i < GRID_SIZE-1 ; i++ )
                	{
                		for(int j = 0 ; j < GRID_SIZE-1 ; j++ )
                		{
                			//staticArray[i][j] = mGridArray[i][j]  ;
                			thirdArray[i][j]=mGridArray[i][j];
                			if(thirdArray[i][j]!=3)//寫在這會是在按確定後下個才回出現 所以不能寫這
                			{
                				//Toast toast = Toast.makeText( parent, "can't conquer", Toast.LENGTH_SHORT);
               	            // toast.show();
                				if_conquer=0;
                			}
                		}
                	}
                	check_bound(shape,x,y);
                	if ((x >= 0 && x < GRID_SIZE - 1) && (y >= 0 && y < GRID_SIZE - 1)) 
                    {
                        if (mGridArray[x][y] == 0||mGridArray[x][y] == 1||mGridArray[x][y] == 2) 
                        {
                            if (wbflag == BLACK) 
                            {
                               for( int i = 0 ; i < 5 ; i++)
                                {
                                	putChess3(x+shape[i][0], y+shape[i][1], BLACK);//上面的格子
                                }
                                if(checkFull())
                                {
                                    mText = STRING_EQUAL;
                                    mGameState = GAMESTATE_END;
                                    //showTextView(mText);
                                }
                                turn = 2 ;
                                wbflag = WHITE;
                            } 
                            else if (wbflag == WHITE) 
                            {
                                for( int i = 0 ; i < 5 ; i++)
                                {
                                	putChess3(x+shape[i][0], y+shape[i][1], WHITE);
                                }
                                if(checkFull()){
                                    mText = STRING_EQUAL;
                                    mGameState = GAMESTATE_END;
                                    //showTextView(mText);
                                }
                                turn = 1 ;
                                wbflag = BLACK;
                            }
                        }
                    }
                	//Toast toast2 = Toast.makeText( parent, "~"+convey, Toast.LENGTH_SHORT);
    	             //toast2.show();
                	
                	/*if ((x >= 0 && x < GRID_SIZE - 1) && (y >= 0 && y < GRID_SIZE - 1)) 
                    {
                	//Toast toast = Toast.makeText( parent, "請按確定", Toast.LENGTH_SHORT);
      	            // toast.show();
      	              parent.b.setEnabled(true);
      	            if_release=0;
                    }else{
                    	//Toast toast = Toast.makeText( parent, "還沒有放置", Toast.LENGTH_SHORT);
         	            // toast.show();
                    	parent.b.setEnabled(false);
                    	if_release=1;
                    }*/
                	
                	for(int i = 0 ; i < GRID_SIZE-1 ; i++ )
                	{
                		for(int j = 0 ; j < GRID_SIZE-1 ; j++ )
                		{
                			
                			convey+=""+thirdArray[i][j];
                			
                		}
                	}
                	//Toast toast2 = Toast.makeText( parent, "e"+convey, Toast.LENGTH_SHORT);
                    //toast2.show();
                	break;
                case MotionEvent.ACTION_MOVE:
                	now_up=makeup;
                	for(int i = 0 ; i < GRID_SIZE-1 ; i++ )
                	{
                		for(int j = 0 ; j < GRID_SIZE-1 ; j++ )
                		{
                			staticArray[i][j] = mGridArray[i][j]  ;
                		}
                	}
                	check_bound(shape,x,y);
                	if ((x >= 0 && x < GRID_SIZE - 1) && (y >= 0 && y < GRID_SIZE - 1)) 
                    {
                		if (mGridArray[x][y] == 0||mGridArray[x][y] == 1||mGridArray[x][y] == 2) 
                        {
                            if (wbflag == BLACK) 
                            {
                               for( int i = 0 ; i < 5 ; i++)
                                {
                                	putChess2(x+shape[i][0], y+shape[i][1], BLACK);
                                }
                               
                                
                            } 
                            else if (wbflag == WHITE) 
                            {
                                for( int i = 0 ; i < 5 ; i++)
                                {
                                	putChess2(x+shape[i][0], y+shape[i][1], WHITE);
                                }
                            }
                        }
                    }
                	break;
                	default:
                		break;
                }
                
            }
            
            break;
        case GAMESTATE_PAUSE:
            break;
        case GAMESTATE_END:
            break;
        }
       } //guess_finger!=0
        this.invalidate();
        return true;
    	 
    } 
    
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent msg) {
        //Log.e("KeyEvent.KEYCODE_DPAD_CENTER", " " + keyCode);
        
        if(keyCode == KeyEvent.KEYCODE_DPAD_CENTER){
            switch(mGameState){
            case GAMESTATE_PRE:
                break;
            case GAMESTATE_RUN:
                break;
            case GAMESTATE_PAUSE:
                break;
            case GAMESTATE_END:
            {//游戏结束后，按CENTER键继续
                
                Log.e("Fire Key Pressed:::", "FIRE");
                mGameState = GAMESTATE_RUN;
                this.setVisibility(View.VISIBLE);
                this.mStatusTextView.setVisibility(View.INVISIBLE);
                this.init();
                this.invalidate();
                
                
            }
                break;           
            }
        }
        
        return super.onKeyDown(keyCode, msg);
    }

    @Override
    public void onDraw(Canvas canvas) {

        canvas.drawColor(Color.BLUE);

        // 画棋盘
        
            Paint paintRect = new Paint();
            paintRect.setColor(Color.RED);
            paintRect.setStrokeWidth(2);
            paintRect.setStyle(Style.STROKE);

            for (int i = 0; i < GRID_SIZE-1; i++) {
                for (int j = 0; j < GRID_SIZE-1; j++) {
                    int mLeft = i * GRID_WIDTH + mStartX;
                    int mTop = j * GRID_WIDTH + mStartY;
                    int mRright = mLeft + GRID_WIDTH;
                    int mBottom = mTop + GRID_WIDTH;
                    canvas.drawRect(mLeft, mTop, mRright, mBottom, paintRect);
                }
            }
            
            //画棋盘的外边框
            paintRect.setStrokeWidth(10);
            canvas.drawRect(mStartX, mStartY, mStartX + GRID_WIDTH*(GRID_SIZE-1), mStartY + ( GRID_WIDTH*(GRID_SIZE-1)), paintRect);
            
            BlueOnline parent = (BlueOnline)getContext();//取的parent的請求 
            int answer=parent.getAnswer();
            int first_enter=parent.getFirstEnter();
        if(answer==0)
        {  //convey="";
        	for(int i = 0 ; i < GRID_SIZE-1 ; i++ )
        	{
        		for(int j = 0 ; j < GRID_SIZE-1 ; j++ )
        		{
        			 mGridArray[i][j]=thirdArray[i][j];
        			 //convey+=""+mGridArray[i][j];
        		}
        	}
        	
        }
        /*Toast toast2 = Toast.makeText( parent, ""+convey, Toast.LENGTH_SHORT);
         toast2.show();*/
        //画棋子
        //convey="";
            paintRect.setStrokeWidth(2);
        for (int i = 0; i <GRID_SIZE-1; i++) {
            for (int j = 0; j <GRID_SIZE-1; j++) {
            	 Paint paintCircle = new Paint();
            	 paintCircle.setStrokeWidth(2);
            	 //convey+=""+mGridArray[i][j];//存陣列
               if(mGridArray[i][j]== BLACK)//非0就畫
               {
            	   paintCircle.setColor(Color.YELLOW);
                   canvas.drawRect(mStartX+(i)*GRID_WIDTH, mStartY+j*GRID_WIDTH ,mStartX+(i+1)* GRID_WIDTH,mStartY +(j+1)* GRID_WIDTH, paintCircle);
               }
               else if(mGridArray[i][j] == WHITE)
               {
            	   paintCircle.setColor(Color.GREEN);
            	   canvas.drawRect(mStartX+i*GRID_WIDTH, mStartY+j*GRID_WIDTH ,mStartX+(i+1)* GRID_WIDTH,mStartY +(j+1)* GRID_WIDTH, paintCircle);
               }
               else{paintCircle.setColor(Color.BLUE);
               }
               if(staticArray[i][j]==BLACK&&makeup==now_up)
               {
            	   paintCircle.setColor(Color.YELLOW);//改WHITE會衝到
                   canvas.drawRect(mStartX+(i)*GRID_WIDTH, mStartY+j*GRID_WIDTH ,mStartX+(i+1)* GRID_WIDTH,mStartY +(j+1)* GRID_WIDTH, paintCircle);
               
               }
               else if(staticArray[i][j]==WHITE&&makeup==now_up)
               {
            	   paintCircle.setColor(Color.GREEN);
                   canvas.drawRect(mStartX+(i)*GRID_WIDTH, mStartY+j*GRID_WIDTH ,mStartX+(i+1)* GRID_WIDTH,mStartY +(j+1)* GRID_WIDTH, paintCircle);
               
               }
               else if(staticArray[i][j]==3&&makeup==now_up)//疊到時
               {
            	   paintCircle.setColor(Color.DKGRAY);
                   canvas.drawRect(mStartX+(i)*GRID_WIDTH, mStartY+j*GRID_WIDTH ,mStartX+(i+1)* GRID_WIDTH,mStartY +(j+1)* GRID_WIDTH, paintCircle);
               
               }
               
               if(thirdArray[i][j]==BLACK&&makeup==now_up+1)
               {   parent.conquer_other=0;
            	   paintCircle.setColor(Color.YELLOW);//改WHITE會衝到
                   canvas.drawRect(mStartX+(i)*GRID_WIDTH, mStartY+j*GRID_WIDTH ,mStartX+(i+1)* GRID_WIDTH,mStartY +(j+1)* GRID_WIDTH, paintCircle);
                   
               }
               else if(thirdArray[i][j]==WHITE&&makeup==now_up+1)
               {   parent.conquer_other=0;
            	   paintCircle.setColor(Color.GREEN);
                   canvas.drawRect(mStartX+(i)*GRID_WIDTH, mStartY+j*GRID_WIDTH ,mStartX+(i+1)* GRID_WIDTH,mStartY +(j+1)* GRID_WIDTH, paintCircle);
                   
               }else if(thirdArray[i][j]==3&&makeup==now_up+1)//有疊到
               {   parent.conquer_other=1;
            	   paintCircle.setColor(Color.DKGRAY);
                   canvas.drawRect(mStartX+(i)*GRID_WIDTH, mStartY+j*GRID_WIDTH ,mStartX+(i+1)* GRID_WIDTH,mStartY +(j+1)* GRID_WIDTH, paintCircle);
                   Toast toast = Toast.makeText(parent, "can't conquer", Toast.LENGTH_SHORT);
     	             toast.show();
     	             parent.b.setEnabled(false);//不能按button
               }
               
            }
        }
        for (int i = 0; i < GRID_SIZE-1; i++) {//整個邊框在繪一次
            for (int j = 0; j < GRID_SIZE-1; j++) {
                int mLeft = i * GRID_WIDTH + mStartX;
                int mTop = j * GRID_WIDTH + mStartY;
                int mRright = mLeft + GRID_WIDTH;
                int mBottom = mTop + GRID_WIDTH;
                canvas.drawRect(mLeft, mTop, mRright, mBottom, paintRect);
            }
        } 
        for(int i=0;i<GRID_SIZE-1;i++)
        {
        	for (int j = 0; j < GRID_SIZE-1; j++) {
                if(thirdArray[i][j]==3)//白色
                	if_conquer=1;
                
        	}
        }
        if(if_conquer==0&&if_release==0)//沒有佔到別的顏色且有放在框框裡
        	parent.b.setEnabled(true);
        
    }
    
    public void putChess(int x, int y, int blackwhite){
        mGridArray[x][y] = blackwhite;
    }
    public void putChess2(int x,int y,int blackwhite){
    	if(staticArray[x][y]==blackwhite)
    	{
    		staticArray[x][y]=blackwhite ;
    	}
    	else if(staticArray[x][y]==0)
    	{
    		staticArray[x][y]=blackwhite ;
    	}
    	else
    	{
    		staticArray[x][y]=3 ;
    	}
    	
    }
    public void putChess3(int x,int y,int blackwhite){
    	if(thirdArray[x][y]==blackwhite)
    	{
    		thirdArray[x][y]=blackwhite;
    	}else if(thirdArray[x][y]==0)
    	{
    		thirdArray[x][y]=blackwhite;
    	}else
    	{
    		thirdArray[x][y]=3;
    	}
    }
    public boolean checkWin(int wbflag){
        for(int i = 0; i < GRID_SIZE - 1 ; i++ ) //i表示列(根据宽度算出来的)
            for(int j = 0; j < GRID_SIZE - 1; j++){//i表示行(根据高度算出来的)
                //检测横轴五个相连
                if(((i+4) < (GRID_SIZE - 1))&&
                   (mGridArray[i][j] == wbflag) && (mGridArray[i+1][j] == wbflag)&& (mGridArray[i + 2][j] == wbflag) && (mGridArray[i + 3][j] == wbflag) && (mGridArray[i + 4][j] == wbflag)){
                    Log.e("check win or loss:", wbflag + "win");
                    
                    mWinFlag = wbflag;
                }
                
                //纵轴5个相连
                if(((j+4) < (GRID_SIZE - 1))&&
                           (mGridArray[i][j] == wbflag) && (mGridArray[i][j+1] == wbflag)&& (mGridArray[i ][j+ 2] == wbflag) && (mGridArray[i ][j+ 3] == wbflag) && (mGridArray[i ][j+ 4] == wbflag)){
                            Log.e("check win or loss:", wbflag + "win");
                            
                            mWinFlag = wbflag;
                        }
                
                //左上到右下5个相连
                if(((j+4) < (GRID_SIZE - 1))&& ((i+4) < (GRID_SIZE - 1)) &&
                           (mGridArray[i][j] == wbflag) && (mGridArray[i+1][j+1] == wbflag)&& (mGridArray[i + 2 ][j+ 2] == wbflag) && (mGridArray[i + 3][j+ 3] == wbflag) && (mGridArray[i + 4 ][j+ 4] == wbflag)){
                            Log.e("check win or loss:", wbflag + "win");
                            
                            mWinFlag = wbflag;
                        }
                
                //右上到左下5个相连
                if(((i-4) >= 0)&& ((j+4) < (GRID_SIZE - 1)) &&
                           (mGridArray[i][j] == wbflag) && (mGridArray[i-1][j+1] == wbflag)&& (mGridArray[i - 2 ][j+ 2] == wbflag) && (mGridArray[i - 3][j+ 3] == wbflag) && (mGridArray[i - 4 ][j+ 4] == wbflag)){
                            Log.e("check win or loss:", wbflag + "win");
                            
                            mWinFlag = wbflag;
                        }
        }
        
        if( mWinFlag == wbflag){
            return true;    
        }else
            return false;
        
        
    }
    
    public boolean checkFull(){
        int mNotEmpty = 0;
        for(int i = 0; i < GRID_SIZE -1; i ++)
            for(int j = 0; j < GRID_SIZE - 1; j ++){
                if(mGridArray[i][j] != 0) mNotEmpty +=1;
            }
        
        if(mNotEmpty == (GRID_SIZE-1)*(GRID_SIZE-1)) return true;
        else return false;
    }
    
    ///////整行滿，換色/////////
    public int check_x(int x)
    {
    	for( int i = 0 ; i < GRID_SIZE - 1 ; i++ )
    	{
    		if(thirdArray[x][i] == 0)
    		{
    			return 0 ;
    		}
    	}
    	return 1 ;
    }
    
    public int check_y(int y)
    {
    	for( int i = 0 ; i < GRID_SIZE - 1 ; i++ )
    	{
    		if(thirdArray[i][y] == 0)
    		{
    			return 0 ;
    		}
    	}
    	return 1 ;
    }
    
    public void draw_x(int x,int turn)
    {
    	for(int i = 0 ; i < GRID_SIZE - 1 ; i++ )
    	{
    		thirdArray[x][i] = turn ;
    	}
    }
    
    public void draw_y(int y,int turn)
    {
    	for(int i = 0 ; i < GRID_SIZE - 1 ; i++ )
    	{
    		thirdArray[i][y] = turn ;
    	}
    }
    
    public void change_line(int x,int y,int temp[][],int turn)
    {
    	int xi , yi;
    	for(int i = 0 ; i < 5 ; i++ )
    	{
    		xi = x+temp[i][0] ;
    		yi = y+temp[i][1] ;
    		if(check_x(xi) == 1 && col[xi] == 0)
    		{	col[xi] = 1 ;
    			draw_x(xi,turn) ;
    		}
    		if(check_y(yi) == 1	&& row[yi] == 0)
    		{	row[yi] = 1 ;
    			draw_y(yi,turn) ;
    		}
    	}
    }
    public void change_line2(int turn)//有bug 是不是col[] 和row[]沒有變成1呢
    {
    	int i,j,k,rowN=0,colN=0,if_change=0;//rowN:row的數量
    	int rowN_all1=0,rowN_all2=0,colN_all1=0,colN_all2=0;
    	int[][] array_if_changed=new int[GRID_SIZE-1][GRID_SIZE-1];
    	
    	for(i=0;i<GRID_SIZE - 1;i++)
    	{
    		for(j=0;j<GRID_SIZE - 1;j++)
    		{
    	     if(mGridArray[i][j]!=thirdArray[i][j])
    	    	 array_if_changed[i][j]=1;//哪些地方變色了
    	     else
    	    	 array_if_changed[i][j]=0;
    		}
    	}
    	
    	for(i=0;i<GRID_SIZE - 1;i++)//先跑直
    	{
    		for(j=0;j<GRID_SIZE - 1;j++)
    		{
    			if(thirdArray[i][j]!=0)//那行滿了
    			{
    				colN++;
    			}
    			if(thirdArray[i][j]==1)//那行都是黃
    				colN_all1++;//9個代表那行之前已經滿了
    			if(thirdArray[i][j]==2)//那行都是綠
    				colN_all2++;
    			if(array_if_changed[i][j]==1)
    				if_change++;
    		}
    		Log.i("Fir", "aaa" + col + colN_all1 + colN_all2);
    		if(colN==9&&colN_all1!=9&&colN_all2!=9&&if_change>0&&col[i] == 0)//之前沒滿但是現在滿了
    		{
    			for(k = 0 ; k < GRID_SIZE - 1 ; k++ )
    	    	{
    	    		thirdArray[i][k] = turn ;//那行全變色
    	    	}
    			col[i]=1;
    		}
    		colN=0;colN_all1=0;colN_all2=0;if_change=0;
    	}
    	for(i=0;i<GRID_SIZE - 1;i++)//再跑列
    	{
    		for(j=0;j<GRID_SIZE - 1;j++)
    		{
    			if(thirdArray[j][i]!=0)//row=9表示那列滿了
    			{
    				rowN++;
    			}
    			if(thirdArray[j][i]==1)
    				rowN_all1++;
    			if(thirdArray[j][i]==2)
    				rowN_all2++;
    			if(array_if_changed[j][i]==1)
    				if_change++;
    		}
    		if(rowN==9&&rowN_all1!=9&&rowN_all2!=9&&if_change>0&&row[i]==0)
    		{
    			for(k = 0 ; k < GRID_SIZE - 1 ; k++ )
    	    	{
    	    		thirdArray[k][i] = turn ;//那列全變色
    	    	}
    			row[i]=1;
    		}
    		rowN=0;rowN_all1=0;rowN_all2=0;if_change=0;
    	}
    }
    public int check_x_blue(int x)
    {
    	for( int i = 0 ; i < GRID_SIZE - 1 ; i++ )
    	{
    		if(mGridArray[x][i] == 0)
    		{
    			return 0 ;
    		}
    	}
    	return 1 ;
    }
    
    public int check_y_blue(int y)
    {
    	for( int i = 0 ; i < GRID_SIZE - 1 ; i++ )
    	{
    		if(mGridArray[i][y] == 0)
    		{
    			return 0 ;
    		}
    	}
    	return 1 ;
    }
    
    public void draw_x_blue(int x,int turn)
    {
    	for(int i = 0 ; i < GRID_SIZE - 1 ; i++ )
    	{
    		mGridArray[x][i] = turn ;
    	}
    }
    
    public void draw_y_blue(int y,int turn)
    {
    	for(int i = 0 ; i < GRID_SIZE - 1 ; i++ )
    	{
    		mGridArray[i][y] = turn ;
    	}
    }
    public void change_line_blue(int x,int y,int temp[][],int turn)
    {
    	int xi , yi;
    	for(int i = 0 ; i < 5 ; i++ )
    	{
    		xi = x+temp[i][0] ;
    		yi = y+temp[i][1] ;
    		if(check_x_blue(xi) == 1)
    		{
    			draw_x_blue(xi,turn) ;
    		}
    		if(check_y_blue(yi) == 1)
    		{
    			draw_y_blue(yi,turn) ;
    		}
    	}
    }
    public int finish(int turn,int index)
    {
    	int temp [][] = new int [5][2] ;
    	shape temp_shape = new shape() ;
    	temp_shape.getShape_XY(index, temp);
    	BlueOnline parent = (BlueOnline)getContext();
    	Toast toast = Toast.makeText(parent, " " + turn, Toast.LENGTH_SHORT);
		toast.show();
    	int empty = 0 ;
    	
    	for( int i = 0 ; i < GRID_SIZE -1 ; i++ )
    	{
    		for( int j = 0 ; j < GRID_SIZE ; j++ )
    		{
    			empty = 0 ;
    			for( int k = 0 ; k < 5 ; k++ )
    			{
    				
    				if( i + temp[k][0] < 0 || i + temp[k][0] >= GRID_SIZE-1 || j + temp[k][1] < 0 || j + temp[k][1] >= GRID_SIZE-1)
    				{
    					break ;
    				}
    				
    				if(thirdArray[i+temp[k][0]][j+temp[k][1]] == 0 || thirdArray[i+temp[k][0]][j+temp[k][1]] == turn)
    				{
    					if(thirdArray[i+temp[k][0]][j+temp[k][1]] == 0 )
    					{
    						//表示有一格是空白
    						empty++ ;
    					}
    					if( k == 4 && empty > 0  )
    					{
    						//toast = Toast.makeText(parent, "3,"+i+j, Toast.LENGTH_SHORT);
            				//toast.show();
    						return 1 ;
    					}
    				}
    				else
    				{
    					break ;
    				}
    			}
    		}
    	}
    	return 0 ;
    }
    ////////////////////////////////////////
    public void showTextView(CharSequence mT){
        this.mStatusTextView.setText(mT);
        mStatusTextView.setVisibility(View.VISIBLE);
        
    }
}

