package com.example.jason.occupy;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;

public class ImageAdapterLevelHard extends BaseAdapter {
    private Context mContext;
    
    public ImageAdapterLevelHard(Context c) {
        mContext = c;
    }

    public ImageAdapterLevelHard(Apple apple) {
		// TODO Auto-generated constructor stub
	}

	public int getCount() {
        return mThumbIds.length;
    }

    public Object getItem(int position) {
        return null;
    }

    public long getItemId(int position) {
        return 0;
    }

    // create a new ImageView for each item referenced by the Adapter
    public View getView(int position, View convertView, ViewGroup parent) {
        ImageView imageView;
       
        if (convertView == null) {
            // if it's not recycled, initialize some attributes
            imageView = new ImageView(mContext);
            imageView.setLayoutParams(new GridView.LayoutParams(250, 250));
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            imageView.setPadding(8, 8, 8, 8);
        } else {
            imageView = (ImageView) convertView;
        }

        imageView.setImageResource(mThumbIds[position]);
        return imageView;
    }

    // references to our images
    private Integer[] mThumbIds = {
    		R.drawable.orangeafter25, R.drawable.orangeafter26,
            R.drawable.orangeafter27, R.drawable.orangeafter28,
            R.drawable.orangeafter29, R.drawable.orangeafter30,
            R.drawable.orangeafter31, R.drawable.orangeafter32,
            R.drawable.orangeafter33, R.drawable.orangeafter34,
            R.drawable.orangeafter35, R.drawable.orangeafter36,
            
    };
}