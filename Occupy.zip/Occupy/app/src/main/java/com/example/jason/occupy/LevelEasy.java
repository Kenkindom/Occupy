package com.example.jason.occupy;


import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.Toast;


public class LevelEasy extends Fragment {
	
		private View v;
		private GridView gridView;
		private int[] image = {
				 R.drawable.orangeafter1, R.drawable.orangeafter2,
		            R.drawable.orangeafter3, R.drawable.orangeafter4,
		            R.drawable.orangeafter5, R.drawable.orangeafter6,
		            R.drawable.orangeafter7, R.drawable.orangeafter8,
		            R.drawable.orangeafter9, R.drawable.orangeafter10,
		            R.drawable.orangeafter11, R.drawable.orangeafter12,
		            R.drawable.orangeafter13, R.drawable.orangeafter14,
		            R.drawable.orangeafter15,/* R.drawable.orange16,
		            R.drawable.orange17, R.drawable.orange18,
		            R.drawable.orange19, R.drawable.orange20,
		            R.drawable.orange21, R.drawable.orange22,
		            R.drawable.orange23, R.drawable.orange24,
		            R.drawable.orange25, R.drawable.orange26,
		            R.drawable.orange27, R.drawable.orange28,
		            R.drawable.orange29, R.drawable.orange30*/
	    };
		@Override
		public void onAttach(Activity activity) {
			super.onAttach(activity);
			
			//BeforeLevel mainActivity = (BeforeLevel)activity;
			//value = mainActivity.getAppleData();
		}
		private String[] imgText = {
	            "1", "2", "3", "4", "5", "6", "7", "8","9","10","11","12","13","14",
	            "15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30"
	    };
		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			
			 v=inflater.inflate(R.layout.level_easy, container, false);
			 GridView gridview = (GridView) v.findViewById(R.id.gridViewLevelEasy);
			 gridview.setAdapter(new ImageAdapterLevelEasy(getActivity()));
			 gridview.setOnItemClickListener(new OnItemClickListener() {
		            public void onItemClick(AdapterView<?> parent, View v,
		                    int position, long id) {
		               
		                Intent it= new Intent();
		                if(position==0)
		                {	//background.setBackgroundColor(Color.GREEN);
		                	
							it.setClass(getActivity(),linear.class);
							it.putExtra("leve","0");
							startActivity(it);
							getActivity().finish();
		                }else if(position==1)
		                {	
							it.setClass(getActivity(),linear.class);
							it.putExtra("leve","1");
							
							startActivity(it);
							getActivity().finish();
		                }else if(position==2)
		                {	//background.setBackgroundColor(Color.BLUE);
		                	it.setClass(getActivity(),linear.class);
							it.putExtra("leve","2");
							
							startActivity(it);
							getActivity().finish();
		                }else if(position==3)
		                {	
							it.setClass(getActivity(),linear.class);
							it.putExtra("leve","3");
							
							startActivity(it);
							getActivity().finish();
		                }else if(position==4)
		                {	
							it.setClass(getActivity(),linear.class);
							it.putExtra("leve","4");
							
							startActivity(it);
							getActivity().finish();
		                }else if(position==5)
		                {	
							it.setClass(getActivity(),linear.class);
							it.putExtra("leve","5");
							
							startActivity(it);
							getActivity().finish();
		                }else if(position==6)
		                {	
							it.setClass(getActivity(),linear.class);
							it.putExtra("leve","6");
							
							startActivity(it);
							getActivity().finish();
		                }else if(position==7)
		                {	
							it.setClass(getActivity(),linear.class);
							it.putExtra("leve","7");
							
							startActivity(it);
							getActivity().finish();
		                }else if(position==8)
		                {	
							it.setClass(getActivity(),linear.class);
							it.putExtra("leve","8");
							
							startActivity(it);
							getActivity().finish();
		                }else if(position==9)//level 10
		                {	
							it.setClass(getActivity(),linear.class);
							it.putExtra("leve","9");
							
							startActivity(it);
							getActivity().finish();
		                }else if(position==10)//level 11
		                {	
							it.setClass(getActivity(),linear.class);
							it.putExtra("leve","10");
							
							startActivity(it);
							getActivity().finish();
		                }else if(position==11)//level 12
		                {	
							it.setClass(getActivity(),linear.class);
							it.putExtra("leve","11");
							
							startActivity(it);
							getActivity().finish();
		                }
		            }
		        });
			 return v;
		}
		
		@Override
		public void onActivityCreated(Bundle savedInstanceState) {
			super.onActivityCreated(savedInstanceState);
			Log.d("=====>", "AppleFragment onActivityCreated");
			// GridView gridview = (GridView) this.getView().findViewById(R.id.gridViewLevel);
		     //   gridview.setAdapter(new ImageAdapterLevel(this));
		       
			//TextView txtResult = (TextView) this.getView().findViewById(R.id.textView1);
			//txtResult.setText(value);
		}
  

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
