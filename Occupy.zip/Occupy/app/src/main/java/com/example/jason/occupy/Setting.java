package com.example.jason.occupy;


import android.app.Activity;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.ImageView;


public class Setting extends Activity {

		private Button start,setting,over;
		ImageView imageView ;
		AnimationDrawable animationDrawable;
		protected void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        //requestWindowFeature(Window.FEATURE_NO_TITLE);//去除標題列
	        setContentView(R.layout.setting);
	        imageView = (ImageView) findViewById(R.id.animation_view);
	        imageView.setBackgroundResource(R.drawable.animation);

	        animationDrawable = (AnimationDrawable)imageView.getBackground();
	        animationDrawable.start();
		}

		@Override
	    public void onDestroy() {
	        super.onDestroy();
	        animationDrawable.stop();

	    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        //getMenuInflater().inflate(R.menu.main, menu);
        //menu.add(1,1,1,"同機雙打");
        //menu.add(1,2,2,"連線對戰");
        //menu.add(1,3,3,"電腦對戰");
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
