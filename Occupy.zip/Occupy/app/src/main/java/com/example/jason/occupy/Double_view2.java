package com.example.jason.occupy;


import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;

public class Double_view2 extends View {
	
	protected int GRID_SIZE = 5;
    protected int GRID_WIDTH = 30; // 棋盘格的宽度
    protected static int mStartX;// 棋盘定位的左上角X
    protected static int mStartY;// 棋盘定位的左上角Y
    int shape_i,index ;
   
    int shape[] = new int[5] ;
	public Double_view2(Context context, AttributeSet attrs) {
		super(context, attrs);
	}
	@Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        mStartX = w / 2 - GRID_SIZE * GRID_WIDTH / 2;
        mStartY = h / 2 - GRID_SIZE * GRID_WIDTH / 2;
      
    }
	
	public int is_in_shape(int i , int j)
	{
		int temp = 0 ;
		for( ; temp < 5 ; temp++ )
		{
			if( shape[temp]%5 == i && shape[temp]/5 == j )
			{
				return 1 ;
			}
		}
		return 0 ;
	}
	
	 @Override
	    public void onDraw(Canvas canvas) {
         int ii;
	        canvas.drawColor(Color.BLACK);
	        shape x = new shape() ;
	         DoubleMan parent = (DoubleMan)getContext(); // I meant this line

	       shape_i = parent.getImportantInt(); 
	         x.adjust(shape_i, shape);
            
	        // 画棋盘
	        {            
	            Paint paintRect_shape = new Paint() ;
	            paintRect_shape.setColor(Color.YELLOW);
	            paintRect_shape.setStrokeWidth(3);
	            paintRect_shape.setStyle(Style.FILL);
	            
	            for (int i = 0 , shape_j = 0; i <GRID_SIZE; i++) {
	                for (int j = 0; j < GRID_SIZE; j++) {
	                    int mLeft = i * GRID_WIDTH + mStartX;
	                    int mTop = j * GRID_WIDTH + mStartY;
	                    int mRright = mLeft + GRID_WIDTH;
	                    int mBottom = mTop + GRID_WIDTH;
	                    if( shape_j < 5 && is_in_shape(i,j) == 1)
	                    {
	                    	canvas.drawRect(mLeft, mTop, mRright, mBottom, paintRect_shape);
	                    	shape_j++ ;
	                    }
	                    
	                }
	            }
	            
	        }
	 	}
	 
}
